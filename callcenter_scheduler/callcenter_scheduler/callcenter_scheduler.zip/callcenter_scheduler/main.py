"""
main.py
API web del sistema de gestión de personal para el call center.

Cómo correrlo local:
    pip install fastapi uvicorn --break-system-packages
    uvicorn main:app --reload
    -> abrir http://localhost:8000

Cuando se despliegue en línea (Railway/Render), este mismo archivo se usa tal cual;
solo cambia DB_PATH a Postgres (ver nota al final).
"""

from datetime import date
from typing import Optional
import os
import shutil
import tempfile

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

import db
from db import DIAS_SEMANA, TIPOS_DISPONIBILIDAD, TIPOS_PERMISO
from validar_disponibilidad import validar_todos
from generador_horarios import (generar_horario_semana, _demanda_por_dia, _ventana_disponibilidad,
                                  HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN, estimar_nivel_servicio_real)
from costos import calcular_costo_horario
from loader_disponibilidad import cargar_disponibilidad_excel
from loader_llamadas import cargar_llamadas_excel
from agregados_llamadas import (metricas_generales, tendencia_semanal_matriz,
                                  resumen_simple_por_dia_semana, resumen_por_dia_semana_y_hora)
from pdf_reporte import (generar_pdf_brecha_personal, generar_pdf_personal, generar_pdf_disponibilidad,
                          generar_pdf_permisos, generar_pdf_metricas, generar_pdf_horario)

db.init_db()

app = FastAPI(title="Call Center Scheduler - API de Personal")


# ---------- Esquemas (validación de entrada) ----------

class EmpleadoCreate(BaseModel):
    nombre: str
    cedula: Optional[str] = None
    horas_min_dia: float = db.DEFAULT_HORAS_MIN_DIA
    horas_max_dia: float = db.DEFAULT_HORAS_MAX_DIA
    horas_min_semana: float = db.DEFAULT_HORAS_MIN_SEMANA
    horas_max_semana: float = db.DEFAULT_HORAS_MAX_SEMANA


class EmpleadoUpdate(BaseModel):
    nombre: Optional[str] = None
    cedula: Optional[str] = None
    activo: Optional[bool] = None
    horas_min_dia: Optional[float] = None
    horas_max_dia: Optional[float] = None
    horas_min_semana: Optional[float] = None
    horas_max_semana: Optional[float] = None


class DisponibilidadSet(BaseModel):
    dia_semana: str
    tipo: str
    hora_inicio: Optional[str] = None
    hora_fin: Optional[str] = None


class PermisoCreate(BaseModel):
    tipo: str
    fecha_inicio: str
    fecha_fin: str
    comentario: str = ""
    forzar: bool = False


# ---------- Empleados ----------

@app.get("/api/empleados")
def api_listar_empleados(solo_activos: bool = True):
    return db.listar_empleados(solo_activos=solo_activos)


@app.post("/api/empleados")
def api_crear_empleado(payload: EmpleadoCreate):
    if payload.horas_min_semana > payload.horas_max_semana:
        raise HTTPException(400, "horas_min_semana no puede ser mayor que horas_max_semana")
    if payload.horas_min_dia > payload.horas_max_dia:
        raise HTTPException(400, "horas_min_dia no puede ser mayor que horas_max_dia")
    emp_id = db.crear_empleado(**payload.model_dump())
    return db.obtener_empleado(emp_id)


@app.get("/api/empleados/pdf")
def api_empleados_pdf():
    ruta = generar_pdf_personal(salida="reporte_personal.pdf")
    return FileResponse(ruta, media_type="application/pdf", filename="reporte_personal.pdf")


@app.get("/api/empleados/{empleado_id}")
def api_obtener_empleado(empleado_id: int):
    emp = db.obtener_empleado(empleado_id)
    if not emp:
        raise HTTPException(404, "Empleado no encontrado")
    emp["disponibilidad"] = db.obtener_disponibilidad(empleado_id)
    emp["permisos"] = db.listar_permisos(empleado_id)
    return emp


@app.put("/api/empleados/{empleado_id}")
def api_actualizar_empleado(empleado_id: int, payload: EmpleadoUpdate):
    if not db.obtener_empleado(empleado_id):
        raise HTTPException(404, "Empleado no encontrado")
    campos = {k: v for k, v in payload.model_dump().items() if v is not None}
    db.actualizar_empleado(empleado_id, **campos)
    return db.obtener_empleado(empleado_id)


@app.delete("/api/empleados/{empleado_id}")
def api_eliminar_empleado(empleado_id: int, definitivo: bool = False):
    if not db.obtener_empleado(empleado_id):
        raise HTTPException(404, "Empleado no encontrado")
    db.eliminar_empleado(empleado_id, definitivo=definitivo)
    return {"ok": True}


# ---------- Disponibilidad ----------

@app.get("/api/empleados/{empleado_id}/disponibilidad")
def api_obtener_disponibilidad(empleado_id: int):
    if not db.obtener_empleado(empleado_id):
        raise HTTPException(404, "Empleado no encontrado")
    return db.obtener_disponibilidad(empleado_id)


@app.put("/api/empleados/{empleado_id}/disponibilidad")
def api_set_disponibilidad(empleado_id: int, payload: DisponibilidadSet):
    if not db.obtener_empleado(empleado_id):
        raise HTTPException(404, "Empleado no encontrado")
    if payload.dia_semana not in DIAS_SEMANA:
        raise HTTPException(400, f"dia_semana debe ser uno de {DIAS_SEMANA}")
    if payload.tipo not in TIPOS_DISPONIBILIDAD:
        raise HTTPException(400, f"tipo debe ser uno de {TIPOS_DISPONIBILIDAD}")
    if payload.tipo == "rango" and not (payload.hora_inicio and payload.hora_fin):
        raise HTTPException(400, "Un rango necesita hora_inicio y hora_fin")

    db.set_disponibilidad(empleado_id, payload.dia_semana, payload.tipo,
                           payload.hora_inicio, payload.hora_fin)
    return db.obtener_disponibilidad(empleado_id)


@app.get("/api/disponibilidad/validacion")
def api_validar_disponibilidad():
    """Usado por el dashboard para mostrar alertas de disponibilidad insuficiente."""
    return validar_todos()


@app.get("/api/disponibilidad/pdf")
def api_disponibilidad_pdf():
    ruta = generar_pdf_disponibilidad(salida="reporte_disponibilidad.pdf")
    return FileResponse(ruta, media_type="application/pdf", filename="reporte_disponibilidad.pdf")


# ---------- Permisos ----------

@app.get("/api/permisos")
def api_listar_permisos(empleado_id: Optional[int] = None):
    return db.listar_permisos(empleado_id)


@app.get("/api/permisos/en-fecha/{fecha}")
def api_permisos_en_fecha(fecha: str):
    return db.empleados_de_permiso_en_fecha(fecha)


@app.post("/api/empleados/{empleado_id}/permisos")
def api_crear_permiso(empleado_id: int, payload: PermisoCreate):
    if not db.obtener_empleado(empleado_id):
        raise HTTPException(404, "Empleado no encontrado")
    if payload.tipo not in TIPOS_PERMISO:
        raise HTTPException(400, f"tipo debe ser uno de {TIPOS_PERMISO}")
    try:
        permiso_id = db.crear_permiso(
            empleado_id, payload.tipo, payload.fecha_inicio, payload.fecha_fin,
            payload.comentario, forzar=payload.forzar,
        )
    except ValueError as e:
        raise HTTPException(409, str(e))
    return {"id": permiso_id}


@app.delete("/api/permisos/{permiso_id}")
def api_eliminar_permiso(permiso_id: int):
    db.eliminar_permiso(permiso_id)
    return {"ok": True}


@app.get("/api/permisos/pdf")
def api_permisos_pdf():
    ruta = generar_pdf_permisos(salida="reporte_permisos.pdf")
    return FileResponse(ruta, media_type="application/pdf", filename="reporte_permisos.pdf")


# ---------- Tarifas ----------

class TarifasUpdate(BaseModel):
    valor_hora_normal: Optional[float] = None
    valor_recargo_dominical: Optional[float] = None
    valor_recargo_nocturno: Optional[float] = None
    valor_subsidio_transporte_hora: Optional[float] = None


@app.get("/api/tarifas")
def api_obtener_tarifas():
    return db.obtener_tarifas()


@app.put("/api/tarifas")
def api_actualizar_tarifas(payload: TarifasUpdate):
    campos = {k: v for k, v in payload.model_dump().items() if v is not None}
    return db.actualizar_tarifas(**campos)


# ---------- Horarios y brecha de personal ----------

def _serializar_horario(resultado: dict, costo: dict, nivel_servicio: dict) -> dict:
    horario_json = {}
    for nombre, dias in resultado["horario"].items():
        horario_json[nombre] = {}
        for dia, info in dias.items():
            if "inicio" in info:
                horario_json[nombre][dia] = {"tipo": "turno", "inicio": info["inicio"], "fin": info["fin"],
                                              "excepcion": info.get("excepcion", False)}
            else:
                horario_json[nombre][dia] = {"tipo": "libre", "motivo": info["motivo"]}

    cobertura_json = {
        dia: [{"hora": h, "requeridos": c["requeridos"], "programados": c["programados"]}
              for h, c in horas.items()]
        for dia, horas in resultado["cobertura"].items()
    }

    return {
        "horario": horario_json,
        "cobertura": cobertura_json,
        "alertas": resultado["alertas"],
        "horas_semana": resultado["horas_semana"],
        "costo": costo,
        "nivel_servicio": nivel_servicio,
    }


@app.get("/api/horario")
def api_generar_horario(fecha_lunes: str, target_service_level: float = 0.95, shrinkage: float = 0.30):
    try:
        lunes = date.fromisoformat(fecha_lunes)
    except ValueError:
        raise HTTPException(400, "fecha_lunes debe tener formato YYYY-MM-DD")

    resultado = generar_horario_semana(lunes, target_service_level=target_service_level, shrinkage=shrinkage)
    costo = calcular_costo_horario(resultado)
    nivel_servicio = estimar_nivel_servicio_real(resultado)
    return _serializar_horario(resultado, costo, nivel_servicio)


@app.get("/api/horario/pdf")
def api_horario_pdf(fecha_lunes: str, target_service_level: float = 0.95, shrinkage: float = 0.30):
    try:
        lunes = date.fromisoformat(fecha_lunes)
    except ValueError:
        raise HTTPException(400, "fecha_lunes debe tener formato YYYY-MM-DD")

    ruta = generar_pdf_horario(lunes, target_service_level=target_service_level, shrinkage=shrinkage,
                                salida="reporte_horario.pdf")
    return FileResponse(ruta, media_type="application/pdf", filename=f"reporte_horario_{fecha_lunes}.pdf")


@app.get("/api/brecha-personal")
def api_brecha_personal(target_service_level: float = 0.95, shrinkage: float = 0.30,
                         horas_contrato_nuevo: float = 36):
    empleados = db.listar_empleados()
    demanda = _demanda_por_dia("callcenter.db", target_service_level, shrinkage)
    disp_cache = {e["id"]: db.obtener_disponibilidad(e["id"]) for e in empleados}

    total_requerido = sum(sum(h.values()) for h in demanda.values())
    capacidad_maxima = sum(e["horas_max_semana"] for e in empleados)
    brecha = max(0, total_requerido - capacidad_maxima)
    asesores_recomendados = -(-brecha // horas_contrato_nuevo) if brecha else 0

    detalle = []
    for h in range(HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN):
        disp_total = req_total = 0
        for dia in DIAS_SEMANA:
            req_total += demanda.get(dia, {}).get(h, 0)
            for e in empleados:
                ventana = _ventana_disponibilidad(disp_cache[e["id"]].get(dia), dia)
                if ventana and ventana[0] <= h < ventana[1]:
                    disp_total += 1
        detalle.append({"hora": h, "requeridos_semana": req_total, "disponibles_semana": disp_total})

    return {
        "total_requerido_semana": total_requerido,
        "capacidad_maxima_semana": capacidad_maxima,
        "brecha_semana": brecha,
        "asesores_recomendados": int(asesores_recomendados),
        "detalle_por_hora": detalle,
    }


@app.get("/api/brecha-personal/pdf")
def api_brecha_personal_pdf(fecha_lunes: str, target_service_level: float = 0.95, shrinkage: float = 0.30):
    try:
        lunes = date.fromisoformat(fecha_lunes)
    except ValueError:
        raise HTTPException(400, "fecha_lunes debe tener formato YYYY-MM-DD")

    ruta = generar_pdf_brecha_personal(lunes, target_service_level=target_service_level, shrinkage=shrinkage,
                                        salida="reporte_brecha_personal.pdf")
    return FileResponse(ruta, media_type="application/pdf",
                         filename=f"reporte_brecha_personal_{fecha_lunes}.pdf")


# ---------- Importar archivos desde el navegador ----------

@app.post("/api/importar/disponibilidad")
async def api_importar_disponibilidad(file: UploadFile = File(...)):
    if not file.filename.lower().endswith((".xlsx", ".xls")):
        raise HTTPException(400, "El archivo debe ser .xlsx o .xls")
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
            shutil.copyfileobj(file.file, tmp)
            tmp_path = tmp.name
        resumen = cargar_disponibilidad_excel(tmp_path)
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)
    return resumen


@app.post("/api/importar/llamadas")
async def api_importar_llamadas(file: UploadFile = File(...)):
    if not file.filename.lower().endswith((".xlsx", ".xls")):
        raise HTTPException(400, "El archivo debe ser .xlsx o .xls")
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
            shutil.copyfileobj(file.file, tmp)
            tmp_path = tmp.name
        resumen = cargar_llamadas_excel(tmp_path)
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)
    return resumen


# ---------- Métricas ----------

@app.get("/api/metricas")
def api_metricas(fecha_inicio: Optional[str] = None, fecha_fin: Optional[str] = None,
                  hora_inicio: Optional[int] = None, hora_fin: Optional[int] = None):
    m = metricas_generales(fecha_inicio=fecha_inicio, fecha_fin=fecha_fin,
                            hora_inicio=hora_inicio, hora_fin=hora_fin)
    if m is None:
        raise HTTPException(404, "Todavía no hay llamadas cargadas. Ve a Importar Datos.")
    return m


@app.get("/api/tendencia-dia-semana")
def api_tendencia_dia_semana(fecha_inicio: Optional[str] = None, fecha_fin: Optional[str] = None):
    return tendencia_semanal_matriz(fecha_inicio=fecha_inicio, fecha_fin=fecha_fin)


@app.get("/api/resumen-dia-semana")
def api_resumen_dia_semana(fecha_inicio: Optional[str] = None, fecha_fin: Optional[str] = None):
    return resumen_simple_por_dia_semana(fecha_inicio=fecha_inicio, fecha_fin=fecha_fin)


@app.get("/api/desglose-dia-hora")
def api_desglose_dia_hora(fecha_inicio: Optional[str] = None, fecha_fin: Optional[str] = None):
    tabla = resumen_por_dia_semana_y_hora(fecha_inicio=fecha_inicio, fecha_fin=fecha_fin)
    return tabla.to_dict(orient="records") if not tabla.empty else []


@app.get("/api/metricas/pdf")
def api_metricas_pdf(fecha_inicio: Optional[str] = None, fecha_fin: Optional[str] = None,
                      hora_inicio: Optional[int] = None, hora_fin: Optional[int] = None):
    ruta = generar_pdf_metricas(fecha_inicio=fecha_inicio, fecha_fin=fecha_fin,
                                 hora_inicio=hora_inicio, hora_fin=hora_fin, salida="reporte_metricas.pdf")
    return FileResponse(ruta, media_type="application/pdf", filename="reporte_metricas.pdf")


# ---------- Frontend estático ----------
# Sirve la interfaz web (HTML/CSS/JS) que consume esta misma API.
app.mount("/", StaticFiles(directory="static", html=True), name="static")


# NOTA PARA DESPLIEGUE EN LÍNEA:
# db.py usa sqlite3 con SQL estándar. Para migrar a Postgres:
#   1. pip install psycopg2-binary
#   2. Cambiar get_conn() en db.py para usar psycopg2 en vez de sqlite3
#   3. El resto del código (funciones CRUD) no cambia casi nada.
