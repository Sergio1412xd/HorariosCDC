# Call Center Scheduler — Sistema de Gestión de Personal

## Cómo correrlo en tu PC

1. Instala las dependencias (una sola vez):
   ```
   pip install -r requirements.txt --break-system-packages
   ```
   (si no usas Linux/`--break-system-packages`, simplemente: `pip install -r requirements.txt`)

2. Levanta el servidor:
   ```
   uvicorn main:app --reload
   ```

3. Abre en el navegador: **http://localhost:8000**

4. Ve a la pestaña **"Importar Datos"** y sube ahí tus dos archivos Excel (disponibilidad
   y llamadas) — ya no hace falta usar la consola para esto.

   ⚠️ **Importante**: la base de datos (`callcenter.db`) NO viene dentro de este zip a
   propósito (para no pisar tu información real con datos de prueba). Esto significa que
   **cada vez que descomprimas una versión nueva del proyecto en una carpeta distinta,
   empieza vacía** y hay que volver a importar los Excel desde "Importar Datos". Si quieres
   conservar tu base de datos entre versiones, copia el archivo `callcenter.db` de la
   carpeta vieja a la nueva antes de arrancar el servidor.

## Qué hay en cada vista

- **Importar Datos**: sube tu Excel de disponibilidad y tu Excel de llamadas directamente
  desde el navegador. Te dice cuántos registros se crearon/actualizaron y si algo faltó
  (cédulas, disponibilidad sin información, etc.). Es seguro repetir la carga de llamadas
  cada semana: las duplicadas se detectan solas y no se cuentan dos veces.
- **Personal**: lista de asesores, sus horas mín/máx diarias y semanales, y una alerta
  automática ("Revisar") si la disponibilidad cargada no alcanza para cumplir su contrato.
  Botón "+ Nuevo asesor" para dar de alta gente nueva.
- **Disponibilidad**: selecciona un asesor y edita día por día — Completa / Rango horario /
  No disponible / Sin información. Se guarda al instante por día.
- **Permisos**: registra vacaciones, capacitación, incapacidades, etc. El sistema bloquea
  automáticamente si intentas crear un permiso que se solapa con uno ya existente para
  ese mismo asesor.
- **Métricas**: KPIs generales del histórico de llamadas (% contestadas, TMO, abandono),
  tendencia diaria y distribución de llamadas por hora del día.
- **Horarios**: elige el lunes de la semana y la meta de nivel de servicio, y genera el
  cuadrante completo con el **% de contestación estimado** (real, con la gente
  efectivamente programada — no el ideal), el costo total, el desglose (recargo nocturno,
  dominical, transporte) y las alertas de horas sin cubrir. El algoritmo corre en 3 pasadas
  (equidad → prioridad → reparación) para que ningún día quede sin gente, ajustando cada
  turno al ancho real del pico de demanda en vez de siempre usar el máximo permitido — esto
  evita desperdiciar horas y deja más presupuesto para otros días. Los turnos de domingo
  respetan un tope de 7h por el costo del recargo dominical (ajustable en
  `generador_horarios.py`, constante `DOMINGO_MAX_HORAS`).
- **Brecha de Personal**: compara la demanda (Erlang C) contra la capacidad actual del
  equipo, hora por hora, te dice cuántos asesores adicionales se recomiendan contratar, y
  tiene un botón para **descargar el reporte en PDF** (con logo y branding) listo para
  presentar a gerencia.
- **Tarifas**: ajusta el valor de la hora normal, el recargo dominical, el recargo nocturno
  y el subsidio de transporte — el cálculo de costos en "Horarios" usa estos valores de
  inmediato, sin reiniciar nada.

## Cargar datos por consola (alternativa a "Importar Datos")

Si prefieres la consola en vez de subir por el navegador:
```
py loader_disponibilidad.py "Disponibilidad_de_horarios.xlsx"
py loader_llamadas.py "llamadas_agosto.xlsx"
```
Ambos son seguros de re-correr: reconocen por nombre/hash lo que ya existe y no duplican.

También puedes generar el horario y el reporte de brecha por consola, si lo prefieres:
```
py generador_horarios.py 2026-09-07
py reporte_brecha_personal.py 2026-09-07 0.95
py costos.py 2026-09-07
```

## Estructura de archivos

```
db.py                       -> Base de datos (SQLite) y funciones CRUD
loader_disponibilidad.py    -> Lee el Excel de disponibilidad
loader_llamadas.py          -> Lee el Excel de llamadas (carga incremental, sin duplicar)
validar_disponibilidad.py   -> Revisa disponibilidad vs mínimos/máximos contractuales
erlang.py                   -> Motor de cálculo de personal requerido (Erlang C)
agregados_llamadas.py       -> Convierte llamadas crudas en promedios por hora/día y métricas
generador_horarios.py       -> Cruza disponibilidad + permisos + Erlang C -> cuadrante semanal
costos.py                   -> Aplica las tarifas al horario generado
reporte_brecha_personal.py  -> Excel de sustento para contratación
main.py                     -> API web (FastAPI) que expone todo lo anterior
static/                     -> Interfaz web (HTML/CSS/JS) que consume la API
callcenter.db                -> Tu base de datos (se crea sola, no viaja en el zip)
```

## Cuando quieras subirlo en línea

Este mismo código sirve tal cual. Los pasos son:
1. Subir el proyecto a un repositorio (GitHub).
2. Desplegarlo en un servicio como Railway o Render (planes desde ~$5-7 USD/mes).
3. Cambiar `db.py` para usar PostgreSQL en vez de SQLite (el servicio de hosting te da
   la base de datos gratis o muy barata incluida). El cambio es solo en la función
   `get_conn()`; el resto del CRUD no cambia porque el SQL es estándar.

No hace falta pagar nada de esto todavía — primero validamos que el sistema completo
funciona bien local contigo.
