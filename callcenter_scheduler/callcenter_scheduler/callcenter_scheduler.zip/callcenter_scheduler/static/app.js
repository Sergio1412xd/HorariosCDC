const API = "/api";
const DIAS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

// ---------- Navegación ----------

document.querySelectorAll(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => mostrarVista(btn.dataset.view));
});

function mostrarVista(nombre) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
  document.getElementById(`view-${nombre}`).classList.add("active");
  document.querySelector(`.nav-item[data-view="${nombre}"]`).classList.add("active");

  if (nombre === "importar") { /* nada que precargar */ }
  if (nombre === "personal") cargarEmpleados();
  if (nombre === "disponibilidad") cargarSelectEmpleados();
  if (nombre === "permisos") cargarPermisos();
  if (nombre === "metricas") cargarMetricas();
  if (nombre === "horarios") inicializarVistaHorarios();
  if (nombre === "brecha") cargarBrecha();
  if (nombre === "tarifas") cargarTarifas();
}

// ---------- Helpers ----------

async function api(path, options = {}) {
  let res;
  try {
    res = await fetch(API + path, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch (e) {
    alert("No se pudo conectar con el servidor. ¿Sigue corriendo 'uvicorn main:app'?");
    throw e;
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(data?.detail || "Error en la solicitud");
  }
  return data;
}

function abrirModal(id) { document.getElementById(id).classList.add("open"); }
function cerrarModal(id) {
  document.getElementById(id).classList.remove("open");
  document.querySelectorAll(`#${id} .error-text`).forEach(e => e.textContent = "");
}

// ---------- PERSONAL ----------

let validacionCache = {};

async function cargarEmpleados() {
  const [empleados, validacion] = await Promise.all([
    api("/empleados"),
    api("/disponibilidad/validacion"),
  ]);
  validacionCache = Object.fromEntries(validacion.map(v => [v.empleado, v]));

  const tbody = document.getElementById("tabla-empleados");

  if (empleados.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5">
      <div class="empty-state">
        Todavía no hay ningún asesor cargado en esta base de datos.<br>
        <a onclick="mostrarVista('importar')">Ir a Importar Datos →</a>
      </div>
    </td></tr>`;
    return;
  }

  tbody.innerHTML = "";

  empleados.forEach(emp => {
    const val = validacionCache[emp.nombre];
    const tieneAlerta = val && val.alertas.length > 0;
    const badge = tieneAlerta
      ? `<span class="badge badge-alerta" title="${val.alertas.join(' · ')}">Revisar</span>`
      : `<span class="badge badge-ok">OK</span>`;

    const tr = document.createElement("tr");
    const cedulaHtml = emp.cedula
      ? emp.cedula
      : `<button class="btn-icon" style="color:var(--rust)" onclick="editarCedula(${emp.id}, '${emp.nombre.replace(/'/g, "")}')">+ Agregar</button>`;
    tr.innerHTML = `
      <td>${emp.nombre}</td>
      <td>${cedulaHtml}</td>
      <td>${emp.horas_min_dia}h – ${emp.horas_max_dia}h</td>
      <td>${emp.horas_min_semana}h – ${emp.horas_max_semana}h</td>
      <td>${badge}</td>
      <td><button class="btn-icon" onclick="eliminarEmpleado(${emp.id}, '${emp.nombre.replace(/'/g, "")}')">Eliminar</button></td>
    `;
    tbody.appendChild(tr);
  });
}

async function editarCedula(id, nombre) {
  const cedula = prompt(`Número de cédula de ${nombre}:`);
  if (!cedula) return;
  await api(`/empleados/${id}`, { method: "PUT", body: JSON.stringify({ cedula: cedula.trim() }) });
  cargarEmpleados();
}

function abrirModalNuevoEmpleado() {
  document.getElementById("emp-nombre").value = "";
  document.getElementById("emp-cedula").value = "";
  document.getElementById("emp-min-dia").value = 4;
  document.getElementById("emp-max-dia").value = 8;
  document.getElementById("emp-min-semana").value = 22;
  document.getElementById("emp-max-semana").value = 36;
  abrirModal("modal-empleado");
}

async function guardarNuevoEmpleado() {
  const errEl = document.getElementById("emp-error");
  const nombre = document.getElementById("emp-nombre").value.trim();
  if (!nombre) { errEl.textContent = "El nombre es obligatorio."; return; }

  try {
    await api("/empleados", {
      method: "POST",
      body: JSON.stringify({
        nombre,
        cedula: document.getElementById("emp-cedula").value.trim() || null,
        horas_min_dia: parseFloat(document.getElementById("emp-min-dia").value),
        horas_max_dia: parseFloat(document.getElementById("emp-max-dia").value),
        horas_min_semana: parseFloat(document.getElementById("emp-min-semana").value),
        horas_max_semana: parseFloat(document.getElementById("emp-max-semana").value),
      }),
    });
    cerrarModal("modal-empleado");
    cargarEmpleados();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function eliminarEmpleado(id, nombre) {
  if (!confirm(`¿Dar de baja a ${nombre}? Su historial de horarios se conserva.`)) return;
  await api(`/empleados/${id}`, { method: "DELETE" });
  cargarEmpleados();
}

// ---------- DISPONIBILIDAD ----------

async function cargarSelectEmpleados() {
  const empleados = await api("/empleados");
  const select = document.getElementById("select-empleado-disp");
  select.innerHTML = empleados.map(e => `<option value="${e.id}">${e.nombre}</option>`).join("");
  if (empleados.length) cargarDisponibilidad();
}

async function cargarDisponibilidad() {
  const empId = document.getElementById("select-empleado-disp").value;
  if (!empId) return;
  const disp = await api(`/empleados/${empId}/disponibilidad`);

  const grid = document.getElementById("grid-disponibilidad");
  grid.innerHTML = DIAS.map(dia => {
    const d = disp[dia] || { tipo: "sin_informacion" };
    return `
      <div class="disp-day">
        <h3>${dia}</h3>
        <select id="tipo-${dia}" onchange="onCambioTipo('${dia}')">
          <option value="completa" ${d.tipo === "completa" ? "selected" : ""}>Completa</option>
          <option value="rango" ${d.tipo === "rango" ? "selected" : ""}>Rango horario</option>
          <option value="no_disponible" ${d.tipo === "no_disponible" ? "selected" : ""}>No disponible</option>
          <option value="sin_informacion" ${d.tipo === "sin_informacion" ? "selected" : ""}>Sin información</option>
        </select>
        <input type="time" id="ini-${dia}" value="${d.hora_inicio || '09:00'}"
               style="${d.tipo === 'rango' ? '' : 'display:none'}">
        <input type="time" id="fin-${dia}" value="${d.hora_fin || '17:00'}"
               style="${d.tipo === 'rango' ? '' : 'display:none'}">
        <button class="btn-ghost" style="width:100%; margin-top:4px; padding:6px;"
                onclick="guardarDisponibilidad('${dia}')">Guardar</button>
      </div>
    `;
  }).join("");
}

function onCambioTipo(dia) {
  const tipo = document.getElementById(`tipo-${dia}`).value;
  const mostrar = tipo === "rango" ? "" : "none";
  document.getElementById(`ini-${dia}`).style.display = mostrar;
  document.getElementById(`fin-${dia}`).style.display = mostrar;
}

async function guardarDisponibilidad(dia) {
  const empId = document.getElementById("select-empleado-disp").value;
  const tipo = document.getElementById(`tipo-${dia}`).value;
  const payload = { dia_semana: dia, tipo };
  if (tipo === "rango") {
    payload.hora_inicio = document.getElementById(`ini-${dia}`).value;
    payload.hora_fin = document.getElementById(`fin-${dia}`).value;
  }
  try {
    await api(`/empleados/${empId}/disponibilidad`, { method: "PUT", body: JSON.stringify(payload) });
  } catch (e) {
    alert(e.message);
  }
}

// ---------- PERMISOS ----------

async function cargarPermisos() {
  const permisos = await api("/permisos");
  const empleados = await api("/empleados");
  const nombreDe = Object.fromEntries(empleados.map(e => [e.id, e.nombre]));

  const tbody = document.getElementById("tabla-permisos");
  tbody.innerHTML = permisos.map(p => `
    <tr>
      <td>${nombreDe[p.empleado_id] || "—"}</td>
      <td>${p.tipo.replace("_", " ")}</td>
      <td>${p.fecha_inicio}</td>
      <td>${p.fecha_fin}</td>
      <td>${p.comentario || ""}</td>
      <td><button class="btn-icon" onclick="eliminarPermiso(${p.id})">Eliminar</button></td>
    </tr>
  `).join("");
}

async function abrirModalNuevoPermiso() {
  const empleados = await api("/empleados");
  document.getElementById("permiso-empleado").innerHTML =
    empleados.map(e => `<option value="${e.id}">${e.nombre}</option>`).join("");
  document.getElementById("permiso-desde").value = "";
  document.getElementById("permiso-hasta").value = "";
  document.getElementById("permiso-comentario").value = "";
  abrirModal("modal-permiso");
}

async function guardarNuevoPermiso() {
  const errEl = document.getElementById("permiso-error");
  const empId = document.getElementById("permiso-empleado").value;
  const tipo = document.getElementById("permiso-tipo").value;
  const desde = document.getElementById("permiso-desde").value;
  const hasta = document.getElementById("permiso-hasta").value;
  const comentario = document.getElementById("permiso-comentario").value;

  if (!desde || !hasta) { errEl.textContent = "Selecciona ambas fechas."; return; }

  try {
    await api(`/empleados/${empId}/permisos`, {
      method: "POST",
      body: JSON.stringify({ tipo, fecha_inicio: desde, fecha_fin: hasta, comentario }),
    });
    cerrarModal("modal-permiso");
    cargarPermisos();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function eliminarPermiso(id) {
  if (!confirm("¿Eliminar este permiso?")) return;
  await api(`/permisos/${id}`, { method: "DELETE" });
  cargarPermisos();
}

// ---------- Init ----------
cargarEmpleados();

// ---------- HORARIOS ----------

function _proximoLunes() {
  const hoy = new Date();
  const dia = hoy.getDay(); // 0=domingo
  const diasHastaLunes = dia === 1 ? 7 : (8 - dia) % 7 || 7;
  const lunes = new Date(hoy);
  lunes.setDate(hoy.getDate() + diasHastaLunes);
  return lunes.toISOString().slice(0, 10);
}

function inicializarVistaHorarios() {
  const input = document.getElementById("horario-fecha");
  if (!input.value) input.value = _proximoLunes();
}

async function generarHorario() {
  const fecha = document.getElementById("horario-fecha").value;
  const sl = document.getElementById("horario-sl").value;
  if (!fecha) { alert("Selecciona el lunes de la semana a generar."); return; }

  const wrap = document.getElementById("horario-tabla-wrap");
  wrap.innerHTML = "<p style='color:var(--text-muted)'>Generando...</p>";

  const data = await api(`/horario?fecha_lunes=${fecha}&target_service_level=${sl}`);
  renderHorario(data);
}

function renderHorario(data) {
  const DIAS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

  // ---- Resumen de costo ----
  const resumen = document.getElementById("horario-resumen-costo");
  resumen.style.display = "grid";
  resumen.innerHTML = `
    <div class="cost-card ${data.nivel_servicio.sl_estimado_semana_pct >= 85 ? 'ok' : 'alert'}">
      <div class="label">% Contestación estimado (semana)</div>
      <div class="value">${data.nivel_servicio.sl_estimado_semana_pct}%</div>
    </div>
    <div class="cost-card">
      <div class="label">Costo total semana</div>
      <div class="value">$${Math.round(data.costo.total_semana).toLocaleString("es-CO")}</div>
    </div>
    <div class="cost-card">
      <div class="label">Recargo nocturno</div>
      <div class="value">$${Math.round(data.costo.desglose.recargo_nocturno).toLocaleString("es-CO")}</div>
    </div>
    <div class="cost-card">
      <div class="label">Extra dominical</div>
      <div class="value">$${Math.round(data.costo.desglose.extra_por_recargo_dominical).toLocaleString("es-CO")}</div>
    </div>
    <div class="cost-card ${data.alertas.length ? 'alert' : 'ok'}">
      <div class="label">Horas sin cubrir</div>
      <div class="value">${data.alertas.filter(a => a.includes('faltan')).length}</div>
    </div>
  `;

  // ---- % contestación por día ----
  const existente = document.getElementById("horario-por-dia-sl");
  if (existente) existente.remove();
  const porDiaDiv = document.createElement("div");
  porDiaDiv.id = "horario-por-dia-sl";
  porDiaDiv.className = "cost-summary";
  porDiaDiv.style.marginTop = "-6px";
  const DIAS_ORD = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
  porDiaDiv.innerHTML = DIAS_ORD.map(dia => {
    const info = data.nivel_servicio.por_dia[dia];
    const pct = info ? info.sl_estimado_pct : null;
    const clase = pct === null ? '' : (pct >= 85 ? 'ok' : 'alert');
    return `<div class="cost-card ${clase}" style="padding:10px 12px;">
      <div class="label">${dia}</div>
      <div class="value" style="font-size:16px;">${pct !== null ? pct + '%' : '—'}</div>
    </div>`;
  }).join("");
  resumen.after(porDiaDiv);

  // ---- Tabla de turnos ----
  const wrap = document.getElementById("horario-tabla-wrap");
  let html = `<table class="horario-table"><thead><tr><th>Asesor</th>`;
  DIAS.forEach(d => html += `<th>${d}</th>`);
  html += `<th>Horas/sem</th><th>Costo</th></tr></thead><tbody>`;

  const motivos = {
    no_disponible: "No disp.", sin_informacion: "Sin info", libre_no_requerido: "Libre",
    tope_semanal_alcanzado: "Tope sem.",
  };

  for (const [nombre, dias] of Object.entries(data.horario)) {
    html += `<tr><td>${nombre}</td>`;
    DIAS.forEach(dia => {
      const info = dias[dia];
      if (info.tipo === "turno") {
        html += `<td class="turno-badge">${String(info.inicio).padStart(2,'0')}-${String(info.fin).padStart(2,'0')}h</td>`;
      } else if (info.motivo && info.motivo.startsWith("permiso:")) {
        html += `<td class="libre-badge">${info.motivo.replace('permiso:', '')}</td>`;
      } else {
        html += `<td class="libre-badge">${motivos[info.motivo] || info.motivo}</td>`;
      }
    });
    const horas = data.horas_semana[nombre] || 0;
    const costo = data.costo.costo_por_empleado[nombre] || 0;
    html += `<td>${horas}h</td><td>$${Math.round(costo).toLocaleString("es-CO")}</td></tr>`;
  }
  html += `</tbody></table>`;
  wrap.innerHTML = html;

  // ---- Alertas ----
  const alertasDiv = document.getElementById("horario-alertas");
  if (data.alertas.length) {
    alertasDiv.innerHTML = `<div class="alertas-box"><strong>${data.alertas.length} alerta(s):</strong><br>` +
      data.alertas.map(a => `<div>• ${a}</div>`).join("") + `</div>`;
  } else {
    alertasDiv.innerHTML = "";
  }
}

// ---------- BRECHA DE PERSONAL ----------

async function cargarBrecha() {
  const data = await api("/brecha-personal");

  const resumen = document.getElementById("brecha-resumen");
  const brechaOk = data.brecha_semana <= 0;
  resumen.innerHTML = `
    <div class="cost-card">
      <div class="label">Requerido / semana</div>
      <div class="value">${data.total_requerido_semana}h</div>
    </div>
    <div class="cost-card">
      <div class="label">Capacidad actual / semana</div>
      <div class="value">${data.capacidad_maxima_semana}h</div>
    </div>
    <div class="cost-card ${brechaOk ? 'ok' : 'alert'}">
      <div class="label">Brecha</div>
      <div class="value">${data.brecha_semana}h</div>
    </div>
    <div class="cost-card ${brechaOk ? 'ok' : 'alert'}">
      <div class="label">Asesores recomendados</div>
      <div class="value">${data.asesores_recomendados}</div>
    </div>
  `;

  const tbody = document.getElementById("tabla-brecha");
  tbody.innerHTML = data.detalle_por_hora.map(fila => {
    const alcanza = fila.disponibles_semana >= fila.requeridos_semana;
    return `<tr>
      <td>${fila.hora}:00</td>
      <td>${fila.requeridos_semana}</td>
      <td>${fila.disponibles_semana}</td>
      <td>${alcanza ? '<span class="badge badge-ok">Alcanza</span>' : '<span class="badge badge-alerta">No alcanza</span>'}</td>
    </tr>`;
  }).join("");
}

// ---------- TARIFAS ----------

async function cargarTarifas() {
  const t = await api("/tarifas");
  document.getElementById("tarifa-normal").value = t.valor_hora_normal;
  document.getElementById("tarifa-dominical").value = t.valor_recargo_dominical;
  document.getElementById("tarifa-nocturno").value = t.valor_recargo_nocturno;
  document.getElementById("tarifa-transporte").value = t.valor_subsidio_transporte_hora;
}

async function descargarPdfSimple(endpoint, nombreArchivo, params = "") {
  const boton = event.target;
  const textoOriginal = boton.textContent;
  boton.textContent = "Generando PDF...";
  boton.disabled = true;
  try {
    const res = await fetch(`${API}${endpoint}${params ? "?" + params : ""}`);
    if (!res.ok) throw new Error("No se pudo generar el PDF");
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = nombreArchivo;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  } catch (e) {
    alert(e.message);
  } finally {
    boton.textContent = textoOriginal;
    boton.disabled = false;
  }
}

function descargarPdfMetricas() {
  descargarPdfSimple("/metricas/pdf", "reporte_metricas.pdf", _filtrosMetricas());
}

function descargarPdfHorario() {
  const fecha = document.getElementById("horario-fecha")?.value || _proximoLunes();
  const sl = document.getElementById("horario-sl")?.value || "0.95";
  descargarPdfSimple("/horario/pdf", `reporte_horario_${fecha}.pdf`, `fecha_lunes=${fecha}&target_service_level=${sl}`);
}

async function descargarPdfBrecha() {
  const fecha = document.getElementById("horario-fecha")?.value || _proximoLunes();
  const boton = event.target;
  const textoOriginal = boton.textContent;
  boton.textContent = "Generando PDF...";
  boton.disabled = true;
  try {
    const res = await fetch(`${API}/brecha-personal/pdf?fecha_lunes=${fecha}&target_service_level=0.95`);
    if (!res.ok) throw new Error("No se pudo generar el PDF");
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `reporte_brecha_personal_${fecha}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  } catch (e) {
    alert(e.message);
  } finally {
    boton.textContent = textoOriginal;
    boton.disabled = false;
  }
}

async function guardarTarifas() {
  const msg = document.getElementById("tarifas-msg");
  await api("/tarifas", {
    method: "PUT",
    body: JSON.stringify({
      valor_hora_normal: parseFloat(document.getElementById("tarifa-normal").value),
      valor_recargo_dominical: parseFloat(document.getElementById("tarifa-dominical").value),
      valor_recargo_nocturno: parseFloat(document.getElementById("tarifa-nocturno").value),
      valor_subsidio_transporte_hora: parseFloat(document.getElementById("tarifa-transporte").value),
    }),
  });
  msg.textContent = "Tarifas guardadas ✓";
  setTimeout(() => msg.textContent = "", 2500);
}

// ---------- IMPORTAR DATOS ----------

async function _subirArchivo(inputId, endpoint) {
  const input = document.getElementById(inputId);
  if (!input.files.length) {
    alert("Selecciona un archivo primero.");
    return null;
  }
  const formData = new FormData();
  formData.append("file", input.files[0]);

  const res = await fetch(API + endpoint, { method: "POST", body: formData });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.detail || "Error al importar el archivo");
  return data;
}

async function subirDisponibilidad() {
  const div = document.getElementById("resultado-disponibilidad");
  div.innerHTML = "Importando...";
  try {
    const r = await _subirArchivo("file-disponibilidad", "/importar/disponibilidad");
    if (!r) return;
    let html = `<span class="ok">${r.empleados_creados} creados, ${r.empleados_actualizados} actualizados.</span>`;
    if (!r.columna_cedula_encontrada) {
      html += `<br><span class="warn">No se encontró columna de Cédula en el archivo.</span>`;
    }
    if (r.celdas_sin_informacion && r.celdas_sin_informacion.length) {
      html += `<br><span class="warn">${r.celdas_sin_informacion.length} celda(s) sin información (revisar disponibilidad manualmente).</span>`;
    }
    div.innerHTML = html;
  } catch (e) {
    div.innerHTML = `<span class="warn">${e.message}</span>`;
  }
}

async function subirLlamadas() {
  const div = document.getElementById("resultado-llamadas");
  div.innerHTML = "Importando (puede tardar unos segundos)...";
  try {
    const r = await _subirArchivo("file-llamadas", "/importar/llamadas");
    if (!r) return;
    div.innerHTML = `<span class="ok">${r.insertadas_nuevas} llamadas nuevas insertadas.</span>` +
      `<br>${r.ya_existian} ya existían (ignoradas, sin duplicar).` +
      `<br>Histórico total: ${r.rango_total_bd.mn} a ${r.rango_total_bd.mx} (${r.rango_total_bd.c} llamadas).`;
  } catch (e) {
    div.innerHTML = `<span class="warn">${e.message}</span>`;
  }
}

// ---------- MÉTRICAS ----------

let chartTendencia = null;
let chartPorHora = null;
let chartTendenciaDiaSemana = null;

function _poblarSelectHoras() {
  ["metricas-hora-inicio", "metricas-hora-fin"].forEach(id => {
    const sel = document.getElementById(id);
    if (sel.options.length > 1) return; // ya poblado
    for (let h = 0; h < 24; h++) {
      const opt = document.createElement("option");
      opt.value = h;
      opt.textContent = `${String(h).padStart(2, '0')}:00`;
      sel.appendChild(opt);
    }
  });
}

function _filtrosMetricas() {
  const p = new URLSearchParams();
  const fi = document.getElementById("metricas-fecha-inicio").value;
  const ff = document.getElementById("metricas-fecha-fin").value;
  const hi = document.getElementById("metricas-hora-inicio").value;
  const hf = document.getElementById("metricas-hora-fin").value;
  if (fi) p.set("fecha_inicio", fi);
  if (ff) p.set("fecha_fin", ff);
  if (hi !== "") p.set("hora_inicio", hi);
  if (hf !== "") p.set("hora_fin", hf);
  return p.toString();
}

function limpiarFiltrosMetricas() {
  document.getElementById("metricas-fecha-inicio").value = "";
  document.getElementById("metricas-fecha-fin").value = "";
  document.getElementById("metricas-hora-inicio").value = "";
  document.getElementById("metricas-hora-fin").value = "";
  cargarMetricas();
}

async function cargarMetricas() {
  _poblarSelectHoras();
  const qs = _filtrosMetricas();
  const kpisDiv = document.getElementById("metricas-kpis");
  let m;
  try {
    m = await api(`/metricas${qs ? "?" + qs : ""}`);
  } catch (e) {
    kpisDiv.innerHTML = `<div class="empty-state" style="grid-column:1/-1;">
      No hay llamadas para ese filtro (o todavía no has importado ninguna).<br>
      <a onclick="mostrarVista('importar')">Ir a Importar Datos →</a>
    </div>`;
    document.querySelectorAll(".chart-card canvas").forEach(c => c.style.display = "none");
    document.getElementById("tabla-resumen-dia-semana").innerHTML = "";
    document.getElementById("tabla-desglose-dia-hora").innerHTML = "";
    return;
  }
  document.querySelectorAll(".chart-card canvas").forEach(c => c.style.display = "block");

  // ---- Tabla de promedio por día de la semana ----
  const resumenDia = await api(`/resumen-dia-semana${qs ? "?" + qs : ""}`);
  document.getElementById("tabla-resumen-dia-semana").innerHTML = resumenDia.map(d => `
    <tr>
      <td>${d.dia_semana}</td>
      <td>${d.dias_observados}</td>
      <td><strong>${Math.round(d.contestadas_promedio)}</strong></td>
      <td>${d.contestadas_min} – ${d.contestadas_max}</td>
      <td>${Math.round(d.abandonadas_promedio)}</td>
      <td>${Math.floor(d.tmo_seg_promedio/60)}:${String(Math.round(d.tmo_seg_promedio%60)).padStart(2,'0')}</td>
    </tr>
  `).join("");

  kpisDiv.innerHTML = `
    <div class="cost-card">
      <div class="label">Llamadas totales (${m.dias_con_datos} días)</div>
      <div class="value">${m.total_llamadas.toLocaleString("es-CO")}</div>
    </div>
    <div class="cost-card ${m.pct_contestadas >= 90 ? 'ok' : 'alert'}">
      <div class="label">% Contestadas</div>
      <div class="value">${m.pct_contestadas}%</div>
    </div>
    <div class="cost-card">
      <div class="label">Abandonadas</div>
      <div class="value">${m.abandonadas.toLocaleString("es-CO")}</div>
    </div>
    <div class="cost-card">
      <div class="label">TMO promedio</div>
      <div class="value">${Math.floor(m.tmo_promedio_seg/60)}:${String(Math.round(m.tmo_promedio_seg%60)).padStart(2,'0')}</div>
    </div>
    <div class="cost-card">
      <div class="label">Espera prom. antes de abandonar</div>
      <div class="value">${Math.round(m.espera_promedio_abandono_seg)}s</div>
    </div>
  `;

  // ---- Gráfica de tendencia diaria ----
  const ctx1 = document.getElementById("chart-tendencia").getContext("2d");
  if (chartTendencia) chartTendencia.destroy();
  chartTendencia = new Chart(ctx1, {
    type: "line",
    data: {
      labels: m.serie_diaria.map(d => d.fecha.slice(5)),
      datasets: [{
        label: "% Contestadas",
        data: m.serie_diaria.map(d => d.pct_contestadas),
        borderColor: "#C98A2C",
        backgroundColor: "rgba(201,138,44,0.1)",
        tension: 0.25, fill: true, pointRadius: 2,
      }],
    },
    options: {
      responsive: true,
      scales: { y: { min: 80, max: 100, ticks: { callback: v => v + "%" } } },
      plugins: { legend: { display: false } },
    },
  });

  // ---- Gráfica por hora del día ----
  const ctx2 = document.getElementById("chart-por-hora").getContext("2d");
  if (chartPorHora) chartPorHora.destroy();
  chartPorHora = new Chart(ctx2, {
    type: "bar",
    data: {
      labels: m.por_hora.map(h => h.hora_del_dia + ":00"),
      datasets: [
        { label: "Contestadas", data: m.por_hora.map(h => h.llamadas_contestadas_prom_dia), backgroundColor: "#2F7A52" },
        { label: "Abandonadas", data: m.por_hora.map(h => h.llamadas_abandonadas_prom_dia), backgroundColor: "#B7541D" },
      ],
    },
    options: {
      responsive: true,
      scales: { x: { stacked: true }, y: { stacked: true } },
      plugins: { legend: { position: "bottom" } },
    },
  });

  // ---- Gráfica de tendencia por día de la semana ----
  const tendenciaDia = await api(`/tendencia-dia-semana${qs ? "?" + qs : ""}`);
  const ctx3 = document.getElementById("chart-tendencia-dia-semana").getContext("2d");
  if (chartTendenciaDiaSemana) chartTendenciaDiaSemana.destroy();
  const coloresSemanas = ["#9CA3AF", "#C98A2C", "#B7541D", "#2F7A52", "#1B2430", "#6B7280"];
  chartTendenciaDiaSemana = new Chart(ctx3, {
    type: "bar",
    data: {
      labels: Object.keys(tendenciaDia.por_dia || {}),
      datasets: (tendenciaDia.semanas || []).map((semana, i) => ({
        label: semana,
        data: Object.values(tendenciaDia.por_dia).map(valores => valores[i]),
        backgroundColor: coloresSemanas[i % coloresSemanas.length],
      })),
    },
    options: {
      responsive: true,
      plugins: { legend: { position: "bottom" } },
    },
  });

  // ---- Tabla matriz: franja horaria x día de la semana ----
  const desglose = await api(`/desglose-dia-hora${qs ? "?" + qs : ""}`);
  const DIAS_ORDEN = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
  const horas = [...new Set(desglose.map(d => d.hora_del_dia))].sort((a, b) => a - b);

  const indice = {};
  desglose.forEach(d => { indice[`${d.dia_semana}-${d.hora_del_dia}`] = d; });

  let htmlMatriz = "<thead><tr><th>Franja</th>";
  DIAS_ORDEN.forEach(d => htmlMatriz += `<th>${d}</th>`);
  htmlMatriz += "</tr></thead><tbody>";

  horas.forEach(h => {
    htmlMatriz += `<tr><td><strong>${h}:00</strong></td>`;
    DIAS_ORDEN.forEach(dia => {
      const celda = indice[`${dia}-${h}`];
      if (celda) {
        const tmoMin = Math.floor(celda.tmo_seg_prom / 60);
        const tmoSeg = String(Math.round(celda.tmo_seg_prom % 60)).padStart(2, '0');
        htmlMatriz += `<td>${Math.round(celda.llamadas_contestadas_prom_dia)} <span style="color:var(--text-muted); font-size:11px;">(TMO ${tmoMin}:${tmoSeg})</span></td>`;
      } else {
        htmlMatriz += `<td style="color:var(--text-muted);">—</td>`;
      }
    });
    htmlMatriz += "</tr>";
  });
  htmlMatriz += "</tbody>";
  document.getElementById("tabla-desglose-dia-hora").innerHTML = htmlMatriz;
}
