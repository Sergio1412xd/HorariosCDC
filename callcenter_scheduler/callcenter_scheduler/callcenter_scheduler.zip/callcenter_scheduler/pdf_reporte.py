"""
pdf_reporte.py
Genera el Reporte de Brecha de Personal en PDF (usando reportlab), con el logo de la
empresa y crédito del sistema, para descargar directamente desde la interfaz web.
"""

import os
import tempfile
from datetime import date

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                  Image, HRFlowable, PageBreak)

from db import listar_empleados, obtener_disponibilidad, DIAS_SEMANA
from generador_horarios import (
    _demanda_por_dia, _ventana_disponibilidad, generar_horario_semana, estimar_nivel_servicio_real,
    HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN,
)
from costos import calcular_costo_horario

ROJO_KFC = colors.HexColor("#C8102E")
NEGRO = colors.HexColor("#1B2430")
GRIS = colors.HexColor("#6B7280")
GRIS_CLARO = colors.HexColor("#F3F3F1")

LOGO_PATH = os.path.join(os.path.dirname(__file__), "static", "assets", "kfc-logo.png")

_styles = getSampleStyleSheet()
TITULO_STYLE = ParagraphStyle("TituloKFC", parent=_styles["Title"], textColor=NEGRO, fontSize=18, spaceAfter=2)
SUBTITULO_STYLE = ParagraphStyle("Subtitulo", parent=_styles["Normal"], textColor=GRIS, fontSize=9, spaceAfter=14)
H2_STYLE = ParagraphStyle("H2", parent=_styles["Heading2"], textColor=ROJO_KFC, fontSize=13, spaceBefore=16, spaceAfter=8)
NORMAL_SMALL_STYLE = ParagraphStyle("NormalSmall", parent=_styles["Normal"], fontSize=9, textColor=NEGRO)
FOOTER_STYLE = ParagraphStyle("Footer", parent=_styles["Normal"], fontSize=8, textColor=GRIS, alignment=1)

ESTILO_TABLA_HEADER_NEGRO = [
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
    ("BACKGROUND", (0, 0), (-1, 0), NEGRO),
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("FONTSIZE", (0, 0), (-1, -1), 9),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, GRIS_CLARO]),
    ("TOPPADDING", (0, 0), (-1, -1), 5),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ("LEFTPADDING", (0, 0), (-1, -1), 6),
]


def _crear_documento(salida: str, apaisado: bool = False) -> SimpleDocTemplate:
    tamano = landscape(letter) if apaisado else letter
    return SimpleDocTemplate(salida, pagesize=tamano, topMargin=1.4*cm, bottomMargin=1.6*cm,
                              leftMargin=1.8*cm, rightMargin=1.8*cm)


def _numero_pagina(canvas, doc):
    """Dibuja el número de página en la esquina inferior derecha de cada hoja."""
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(GRIS)
    canvas.drawRightString(doc.pagesize[0] - 1.8*cm, 1.0*cm, f"Página {canvas.getPageNumber()}")
    canvas.restoreState()


def _grafico_linea_pct_contestadas(serie_diaria: list) -> str:
    """Genera la gráfica de % de contestación por día y devuelve la ruta del PNG temporal."""
    fechas = [d["fecha"][5:] for d in serie_diaria]
    valores = [d["pct_contestadas"] for d in serie_diaria]

    fig, ax = plt.subplots(figsize=(9.5, 2.6), dpi=150)
    ax.plot(fechas, valores, color="#C8102E", marker="o", markersize=3, linewidth=1.6)
    ax.axhline(90, color="#9CA3AF", linestyle="--", linewidth=1)
    ymin = min(75, min(valores) - 5) if valores else 75
    ax.set_ylim(ymin, 101)
    ax.set_title("% de contestación por día", fontsize=10, color="#1B2430", loc="left", fontweight="bold")
    ax.tick_params(axis="x", labelsize=6.5, rotation=60)
    ax.tick_params(axis="y", labelsize=7.5)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="y", color="#E1E3DF", linewidth=0.6)
    fig.tight_layout()

    ruta = tempfile.NamedTemporaryFile(delete=False, suffix=".png").name
    fig.savefig(ruta)
    plt.close(fig)
    return ruta


def _grafico_barras_por_hora(por_hora: list) -> str:
    """Genera la gráfica apilada de contestadas/abandonadas por hora y devuelve la ruta del PNG."""
    horas = [f"{int(h['hora_del_dia'])}h" for h in por_hora]
    contestadas = [h["llamadas_contestadas_prom_dia"] for h in por_hora]
    abandonadas = [h["llamadas_abandonadas_prom_dia"] for h in por_hora]

    fig, ax = plt.subplots(figsize=(9.5, 2.6), dpi=150)
    x = range(len(horas))
    ax.bar(x, contestadas, color="#1B2430", label="Contestadas", width=0.6)
    ax.bar(x, abandonadas, bottom=contestadas, color="#C8102E", label="Abandonadas", width=0.6)
    ax.set_xticks(list(x))
    ax.set_xticklabels(horas, fontsize=7)
    ax.tick_params(axis="y", labelsize=7.5)
    ax.set_title("Llamadas por hora del día (promedio)", fontsize=10, color="#1B2430", loc="left", fontweight="bold")
    ax.legend(fontsize=7.5, frameon=False, loc="upper right")
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="y", color="#E1E3DF", linewidth=0.6)
    fig.tight_layout()

    ruta = tempfile.NamedTemporaryFile(delete=False, suffix=".png").name
    fig.savefig(ruta)
    plt.close(fig)
    return ruta


def _grafico_barras_dia_semana(resumen_dia: list) -> str:
    """Genera la gráfica de promedio de llamadas contestadas por día de la semana."""
    dias = [d["dia_semana"] for d in resumen_dia]
    valores = [d["contestadas_promedio"] for d in resumen_dia]

    fig, ax = plt.subplots(figsize=(9.5, 2.6), dpi=150)
    ax.bar(dias, valores, color="#C8102E", width=0.55)
    ax.set_title("Promedio de llamadas contestadas por día de la semana", fontsize=10, color="#1B2430",
                 loc="left", fontweight="bold")
    ax.tick_params(axis="x", labelsize=8)
    ax.tick_params(axis="y", labelsize=7.5)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="y", color="#E1E3DF", linewidth=0.6)
    fig.tight_layout()

    ruta = tempfile.NamedTemporaryFile(delete=False, suffix=".png").name
    fig.savefig(ruta)
    plt.close(fig)
    return ruta


def _encabezado(titulo_texto: str, subtitulo_texto: str) -> list:
    """Devuelve los flowables de encabezado (logo + título + subtítulo + línea) comunes a todos los reportes."""
    story = []
    if os.path.exists(LOGO_PATH):
        logo = Image(LOGO_PATH, width=1.6*cm, height=1.48*cm)
        header_table = Table([[logo, Paragraph(titulo_texto, TITULO_STYLE)]], colWidths=[2*cm, 14*cm])
        header_table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (0, 0), 0),
        ]))
        story.append(header_table)
    else:
        story.append(Paragraph(titulo_texto, TITULO_STYLE))
    story.append(Paragraph(subtitulo_texto, SUBTITULO_STYLE))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E1E3DF"), thickness=1))
    return story


def _pie_pagina() -> list:
    """Devuelve los flowables de pie de página (línea + crédito) comunes a todos los reportes."""
    return [
        Spacer(1, 20),
        HRFlowable(width="100%", color=colors.HexColor("#E1E3DF"), thickness=1),
        Spacer(1, 6),
        Paragraph(
            f"Sistema de Gestión de Personal y Horarios — Call Center · Desarrollado por Sergio Ortiz · © {date.today().year}",
            FOOTER_STYLE),
    ]


def generar_pdf_brecha_personal(fecha_lunes: date, target_service_level: float = 0.95,
                                 shrinkage: float = 0.30, db_path: str = "callcenter.db",
                                 horas_contrato_nuevo: float = 36,
                                 salida: str = "reporte_brecha_personal.pdf") -> str:

    empleados = listar_empleados(db_path=db_path)
    demanda = _demanda_por_dia(db_path, target_service_level, shrinkage)
    disp_cache = {e["id"]: obtener_disponibilidad(e["id"], db_path=db_path) for e in empleados}

    total_requerido = sum(sum(h.values()) for h in demanda.values())
    capacidad_maxima = sum(e["horas_max_semana"] for e in empleados)
    brecha = max(0, total_requerido - capacidad_maxima)
    asesores_recomendados = -(-brecha // horas_contrato_nuevo) if brecha else 0

    detalle = []
    for h in range(HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN):
        disp_total = req_total = 0
        for dia in DIAS_SEMANA:
            req_total += demanda.get(dia, {}).get(h, 0)
            for e in empleados:
                ventana = _ventana_disponibilidad(disp_cache[e["id"]].get(dia), dia)
                if ventana and ventana[0] <= h < ventana[1]:
                    disp_total += 1
        detalle.append({"hora": h, "requeridos": req_total, "disponibles": disp_total})

    resultado_horario = generar_horario_semana(fecha_lunes, db_path=db_path,
                                                target_service_level=target_service_level, shrinkage=shrinkage)
    costo = calcular_costo_horario(resultado_horario, db_path=db_path)
    nivel_servicio = estimar_nivel_servicio_real(resultado_horario)

    # ================= Construcción del PDF =================
    doc = SimpleDocTemplate(salida, pagesize=letter, topMargin=1.6*cm, bottomMargin=1.6*cm,
                             leftMargin=1.8*cm, rightMargin=1.8*cm)
    styles = getSampleStyleSheet()
    titulo = ParagraphStyle("TituloKFC", parent=styles["Title"], textColor=NEGRO, fontSize=18, spaceAfter=2)
    subtitulo = ParagraphStyle("Subtitulo", parent=styles["Normal"], textColor=GRIS, fontSize=9, spaceAfter=14)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], textColor=ROJO_KFC, fontSize=13, spaceBefore=16, spaceAfter=8)
    normal = styles["Normal"]
    normal_small = ParagraphStyle("NormalSmall", parent=styles["Normal"], fontSize=9, textColor=NEGRO)
    footer_style = ParagraphStyle("Footer", parent=styles["Normal"], fontSize=8, textColor=GRIS, alignment=1)

    story = []

    # ---- Encabezado con logo ----
    if os.path.exists(LOGO_PATH):
        logo = Image(LOGO_PATH, width=1.6*cm, height=1.48*cm)
        header_table = Table([[logo, Paragraph("Reporte de Brecha de Personal<br/>Call Center", titulo)]],
                              colWidths=[2*cm, 14*cm])
        header_table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (0, 0), 0),
        ]))
        story.append(header_table)
    else:
        story.append(Paragraph("Reporte de Brecha de Personal — Call Center", titulo))

    story.append(Paragraph(
        f"Semana del {fecha_lunes.isoformat()} &nbsp;|&nbsp; Meta de nivel de servicio: {int(target_service_level*100)}% "
        f"&nbsp;|&nbsp; Shrinkage: {int(shrinkage*100)}% &nbsp;|&nbsp; Generado: {date.today().isoformat()}",
        subtitulo))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E1E3DF"), thickness=1))

    # ---- Resumen ejecutivo ----
    story.append(Paragraph("Resumen ejecutivo", h2))
    filas_resumen = [
        ["Agentes activos actuales", str(len(empleados))],
        ["Agente-horas requeridas / semana", str(total_requerido)],
        ["Capacidad máxima actual (todos al tope semanal)", f"{capacidad_maxima:.0f}"],
        ["Brecha (agente-horas / semana)", f"{brecha:.0f}"],
        ["Brecha (%)", f"{brecha/total_requerido*100:.1f}%" if total_requerido else "0%"],
        ["% Contestación estimado con la plantilla actual", f"{nivel_servicio['sl_estimado_semana_pct']}%"],
        ["Costo semanal del horario generado", f"${costo['total_semana']:,.0f}"],
        ["Asesores adicionales recomendados", str(int(asesores_recomendados))],
    ]
    t = Table(filas_resumen, colWidths=[10.5*cm, 5.5*cm])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("TEXTCOLOR", (0, 0), (0, -1), NEGRO),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("TEXTCOLOR", (1, -1), (1, -1), ROJO_KFC),
        ("FONTSIZE", (1, -1), (1, -1), 12),
        ("ROWBACKGROUNDS", (0, 0), (-1, -2), [colors.white, GRIS_CLARO]),
        ("LINEBELOW", (0, 0), (-1, -1), 0.5, colors.HexColor("#E1E3DF")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(t)

    story.append(Paragraph(
        "<b>Conclusión:</b> la disponibilidad horaria del equipo actual alcanza a cubrir casi todas las "
        "franjas del día si se ignora el tope de horas semanales — el cuello de botella es la CANTIDAD "
        "de personas, no la distribución de turnos. Se recomienda contratar más asesores con "
        "disponibilidad similar a la actual.", ParagraphStyle("Concl", parent=normal_small, spaceBefore=10, spaceAfter=4)))

    # ---- Detalle por hora ----
    story.append(Paragraph("Demanda vs. disponibilidad total del equipo, por hora (semana)", h2))
    filas_detalle = [["Hora", "Requeridos", "Disponibles (sin tope)", "¿Alcanza?"]]
    for f in detalle:
        alcanza = "Sí" if f["disponibles"] >= f["requeridos"] else "No alcanza"
        filas_detalle.append([f"{f['hora']:02d}:00", str(f["requeridos"]), str(f["disponibles"]), alcanza])
    t2 = Table(filas_detalle, colWidths=[3*cm, 4*cm, 5*cm, 4*cm], repeatRows=1)
    estilo_t2 = [
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("BACKGROUND", (0, 0), (-1, 0), NEGRO),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, GRIS_CLARO]),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    for i, f in enumerate(detalle, start=1):
        if f["disponibles"] < f["requeridos"]:
            estilo_t2.append(("TEXTCOLOR", (3, i), (3, i), ROJO_KFC))
            estilo_t2.append(("FONTNAME", (3, i), (3, i), "Helvetica-Bold"))
    t2.setStyle(TableStyle(estilo_t2))
    story.append(t2)

    # ---- % contestación estimado por día ----
    story.append(Paragraph("% de contestación estimado por día (con la plantilla actual)", h2))
    filas_sl = [["Día"] + DIAS_SEMANA]
    valores_sl = ["% Contestación"]
    for dia in DIAS_SEMANA:
        info = nivel_servicio["por_dia"].get(dia, {})
        pct = info.get("sl_estimado_pct")
        valores_sl.append(f"{pct}%" if pct is not None else "—")
    filas_sl.append(valores_sl)
    t3 = Table(filas_sl, colWidths=[2.3*cm] + [2*cm]*7)
    t3.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, 0), (0, -1), NEGRO),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("ROWBACKGROUNDS", (1, 1), (-1, 1), [GRIS_CLARO]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(t3)

    # ---- Footer / créditos ----
    story.append(Spacer(1, 24))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#E1E3DF"), thickness=1))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "Sistema de Gestión de Personal y Horarios — Call Center · Desarrollado por Sergio Ortiz "
        f"· © {date.today().year}", footer_style))

    doc.build(story, onFirstPage=_numero_pagina, onLaterPages=_numero_pagina)
    return salida


def generar_pdf_horario(fecha_lunes: date, target_service_level: float = 0.95, shrinkage: float = 0.30,
                         db_path: str = "callcenter.db", salida: str = "reporte_horario.pdf") -> str:
    """PDF dedicado al horario generado: cuadrante completo de turnos, costo y % de contestación
    estimado por día. Distinto del reporte de brecha (que se enfoca en sustentar contratación)."""
    resultado = generar_horario_semana(fecha_lunes, db_path=db_path,
                                        target_service_level=target_service_level, shrinkage=shrinkage)
    costo = calcular_costo_horario(resultado, db_path=db_path)
    nivel_servicio = estimar_nivel_servicio_real(resultado)

    doc = _crear_documento(salida, apaisado=True)
    story = _encabezado("Horario Semanal — Call Center",
                         f"Semana del {fecha_lunes.isoformat()} &nbsp;|&nbsp; Meta de servicio: "
                         f"{int(target_service_level*100)}% &nbsp;|&nbsp; Generado: {date.today().isoformat()}")

    # ---- Resumen ----
    huecos = len([a for a in resultado["alertas"] if "faltan" in a])
    filas_resumen = [
        ["% Contestación estimado (semana)", f"{nivel_servicio['sl_estimado_semana_pct']}%",
         "Costo total semana", f"${costo['total_semana']:,.0f}"],
        ["Horas-persona programadas", f"{sum(resultado['horas_semana'].values()):.0f}h",
         "Horas sin cubrir (alertas)", str(huecos)],
    ]
    t0 = Table(filas_resumen, colWidths=[6.5*cm, 4*cm, 6.5*cm, 4*cm])
    t0.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, GRIS_CLARO]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(t0)
    story.append(Spacer(1, 14))

    # ---- % contestación por día ----
    story.append(Paragraph("% de contestación estimado por día", H2_STYLE))
    filas_sl = [["Día"] + DIAS_SEMANA]
    valores_sl = ["% Contestación"]
    for dia in DIAS_SEMANA:
        info = nivel_servicio["por_dia"].get(dia, {})
        pct = info.get("sl_estimado_pct")
        valores_sl.append(f"{pct}%" if pct is not None else "—")
    filas_sl.append(valores_sl)
    t1 = Table(filas_sl, colWidths=[3*cm] + [3*cm]*7)
    t1.setStyle(TableStyle(ESTILO_TABLA_HEADER_NEGRO + [("ALIGN", (1, 0), (-1, -1), "CENTER")]))
    story.append(t1)
    story.append(Spacer(1, 16))

    # ---- Cuadrante de turnos ----
    story.append(Paragraph("Cuadrante de turnos", H2_STYLE))
    motivos_abrev = {"no_disponible": "No disp.", "sin_informacion": "Sin info",
                      "libre_no_requerido": "Libre", "tope_semanal_alcanzado": "Tope sem."}
    filas_horario = [["Asesor"] + DIAS_SEMANA + ["Horas/sem"]]
    for nombre, dias in resultado["horario"].items():
        fila = [nombre]
        for dia in DIAS_SEMANA:
            info = dias.get(dia, {"motivo": "?"})
            if "inicio" in info:
                marca = "*" if info.get("excepcion") else ""
                fila.append(f"{info['inicio']:02d}-{info['fin']:02d}h{marca}")
            else:
                motivo = info.get("motivo", "?")
                if motivo.startswith("permiso:"):
                    fila.append(motivo.replace("permiso:", "").capitalize())
                else:
                    fila.append(motivos_abrev.get(motivo, motivo))
        fila.append(f"{resultado['horas_semana'][nombre]:.0f}h")
        filas_horario.append(fila)

    t2 = Table(filas_horario, colWidths=[3.6*cm] + [2.7*cm]*7 + [2*cm], repeatRows=1)
    t2.setStyle(TableStyle(ESTILO_TABLA_HEADER_NEGRO + [("FONTSIZE", (0, 0), (-1, -1), 7.5)]))
    story.append(t2)
    story.append(Paragraph("* turno de excepción por debajo del mínimo diario, asignado para no dejar la hora sin cobertura",
                            ParagraphStyle("Nota", parent=NORMAL_SMALL_STYLE, fontSize=7.5, textColor=GRIS)))

    # ---- Alertas ----
    if resultado["alertas"]:
        story.append(PageBreak())
        story.append(Paragraph(f"Alertas ({len(resultado['alertas'])})", H2_STYLE))
        for a in resultado["alertas"][:60]:
            story.append(Paragraph(f"• {a}", ParagraphStyle("Alerta", parent=NORMAL_SMALL_STYLE, fontSize=8)))

    story.extend(_pie_pagina())
    doc.build(story, onFirstPage=_numero_pagina, onLaterPages=_numero_pagina)
    return salida


def generar_pdf_personal(db_path: str = "callcenter.db", salida: str = "reporte_personal.pdf") -> str:
    """PDF con la lista de asesores, sus reglas de horas y su estado de disponibilidad."""
    from validar_disponibilidad import validar_todos

    empleados = listar_empleados(db_path=db_path)
    validacion = {v["empleado"]: v for v in validar_todos(db_path=db_path)}

    doc = _crear_documento(salida)
    story = _encabezado("Personal — Call Center",
                         f"{len(empleados)} asesores activos &nbsp;|&nbsp; Generado: {date.today().isoformat()}")

    filas = [["Asesor", "Cédula", "Horas/día", "Horas/semana", "Estado"]]
    for e in empleados:
        val = validacion.get(e["nombre"])
        estado = "Revisar" if (val and val["alertas"]) else "OK"
        filas.append([
            e["nombre"], e.get("cedula") or "—",
            f"{e['horas_min_dia']:.0f}–{e['horas_max_dia']:.0f}h",
            f"{e['horas_min_semana']:.0f}–{e['horas_max_semana']:.0f}h",
            estado,
        ])

    t = Table(filas, colWidths=[5.5*cm, 3*cm, 2.7*cm, 3*cm, 2.3*cm], repeatRows=1)
    estilo = list(ESTILO_TABLA_HEADER_NEGRO)
    for i, e in enumerate(empleados, start=1):
        val = validacion.get(e["nombre"])
        if val and val["alertas"]:
            estilo.append(("TEXTCOLOR", (4, i), (4, i), ROJO_KFC))
            estilo.append(("FONTNAME", (4, i), (4, i), "Helvetica-Bold"))
    t.setStyle(TableStyle(estilo))
    story.append(t)
    story.extend(_pie_pagina())

    doc.build(story, onFirstPage=_numero_pagina, onLaterPages=_numero_pagina)
    return salida


def generar_pdf_disponibilidad(db_path: str = "callcenter.db", salida: str = "reporte_disponibilidad.pdf") -> str:
    """PDF con la matriz de disponibilidad de todos los asesores (día por día)."""
    empleados = listar_empleados(db_path=db_path)

    doc = _crear_documento(salida)
    story = _encabezado("Disponibilidad — Call Center",
                         f"{len(empleados)} asesores &nbsp;|&nbsp; Generado: {date.today().isoformat()}")

    dias_abrev = {"Lunes": "Lun", "Martes": "Mar", "Miércoles": "Mié", "Jueves": "Jue",
                  "Viernes": "Vie", "Sábado": "Sáb", "Domingo": "Dom"}
    filas = [["Asesor"] + [dias_abrev[d] for d in DIAS_SEMANA]]

    for e in empleados:
        disp = obtener_disponibilidad(e["id"], db_path=db_path)
        fila = [e["nombre"]]
        for dia in DIAS_SEMANA:
            d = disp.get(dia)
            if not d:
                fila.append("—")
            elif d["tipo"] == "completa":
                fila.append("Completa")
            elif d["tipo"] == "rango":
                fila.append(f"{d['hora_inicio']}-{d['hora_fin']}")
            elif d["tipo"] == "no_disponible":
                fila.append("No disp.")
            else:
                fila.append("Sin info")
        filas.append(fila)

    t = Table(filas, colWidths=[4*cm] + [2.1*cm]*7, repeatRows=1)
    t.setStyle(TableStyle(ESTILO_TABLA_HEADER_NEGRO + [("FONTSIZE", (0, 0), (-1, -1), 8)]))
    story.append(t)
    story.extend(_pie_pagina())

    doc.build(story, onFirstPage=_numero_pagina, onLaterPages=_numero_pagina)
    return salida


def generar_pdf_permisos(db_path: str = "callcenter.db", salida: str = "reporte_permisos.pdf") -> str:
    """PDF con el listado de permisos/ausencias registrados."""
    from db import listar_permisos

    empleados = {e["id"]: e["nombre"] for e in listar_empleados(db_path=db_path, solo_activos=False)}
    permisos = listar_permisos(db_path=db_path)
    permisos = sorted(permisos, key=lambda p: p["fecha_inicio"])

    doc = _crear_documento(salida)
    story = _encabezado("Permisos y Ausencias — Call Center",
                         f"{len(permisos)} registros &nbsp;|&nbsp; Generado: {date.today().isoformat()}")

    if permisos:
        filas = [["Asesor", "Tipo", "Desde", "Hasta", "Comentario"]]
        for p in permisos:
            filas.append([
                empleados.get(p["empleado_id"], "—"),
                p["tipo"].replace("_", " ").capitalize(),
                p["fecha_inicio"], p["fecha_fin"], p.get("comentario") or "",
            ])
        t = Table(filas, colWidths=[4*cm, 3*cm, 2.5*cm, 2.5*cm, 4.5*cm], repeatRows=1)
        t.setStyle(TableStyle(ESTILO_TABLA_HEADER_NEGRO))
        story.append(t)
    else:
        story.append(Paragraph("No hay permisos registrados todavía.", NORMAL_SMALL_STYLE))

    story.extend(_pie_pagina())
    doc.build(story, onFirstPage=_numero_pagina, onLaterPages=_numero_pagina)
    return salida


def generar_pdf_metricas(fecha_inicio: str = None, fecha_fin: str = None,
                          hora_inicio: int = None, hora_fin: int = None,
                          db_path: str = "callcenter.db", salida: str = "reporte_metricas.pdf") -> str:
    """PDF completo de métricas: KPIs, gráficas, promedio por día y desglose día x hora,
    respetando los mismos filtros de fecha/hora que el dashboard web."""
    from agregados_llamadas import metricas_generales, resumen_simple_por_dia_semana, resumen_por_dia_semana_y_hora

    m = metricas_generales(db_path=db_path, fecha_inicio=fecha_inicio, fecha_fin=fecha_fin,
                            hora_inicio=hora_inicio, hora_fin=hora_fin)
    resumen_dia = resumen_simple_por_dia_semana(db_path=db_path, fecha_inicio=fecha_inicio, fecha_fin=fecha_fin)
    desglose = resumen_por_dia_semana_y_hora(db_path=db_path, fecha_inicio=fecha_inicio, fecha_fin=fecha_fin)

    rango_txt = ""
    if fecha_inicio or fecha_fin:
        rango_txt = f" &nbsp;|&nbsp; Rango: {fecha_inicio or '...'} a {fecha_fin or '...'}"
    if hora_inicio is not None or hora_fin is not None:
        rango_txt += f" &nbsp;|&nbsp; Horas: {hora_inicio if hora_inicio is not None else '00'}:00-{hora_fin if hora_fin is not None else '23'}:00"

    doc = _crear_documento(salida, apaisado=True)
    story = _encabezado("Métricas — Call Center", f"Generado: {date.today().isoformat()}{rango_txt}")

    if m is None:
        story.append(Paragraph("No hay llamadas para el filtro seleccionado.", NORMAL_SMALL_STYLE))
        doc.build(story, onFirstPage=_numero_pagina, onLaterPages=_numero_pagina)
        return salida

    rutas_temp = []
    ancho_pagina_util = 24.5 * cm  # letter horizontal menos márgenes

    # ---- KPIs ----
    story.append(Paragraph("KPIs generales", H2_STYLE))
    filas_kpi = [
        ["Llamadas totales", f"{m['total_llamadas']:,}", "% Contestadas", f"{m['pct_contestadas']}%"],
        ["Días con datos", str(m["dias_con_datos"]), "Abandonadas", f"{m['abandonadas']:,}"],
        ["TMO promedio", f"{int(m['tmo_promedio_seg']//60)}:{int(m['tmo_promedio_seg']%60):02d}",
         "Espera prom. antes de abandonar", f"{m['espera_promedio_abandono_seg']:.0f}s"],
    ]
    t1 = Table(filas_kpi, colWidths=[6*cm, 4*cm, 7*cm, 4*cm])
    t1.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, GRIS_CLARO]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(t1)
    story.append(Spacer(1, 10))

    # ---- Gráficas ----
    if m.get("serie_diaria"):
        ruta = _grafico_linea_pct_contestadas(m["serie_diaria"])
        rutas_temp.append(ruta)
        story.append(Image(ruta, width=ancho_pagina_util, height=ancho_pagina_util * 2.6/9.5))

    if m.get("por_hora"):
        ruta = _grafico_barras_por_hora(m["por_hora"])
        rutas_temp.append(ruta)
        story.append(Image(ruta, width=ancho_pagina_util, height=ancho_pagina_util * 2.6/9.5))

    if resumen_dia:
        ruta = _grafico_barras_dia_semana(resumen_dia)
        rutas_temp.append(ruta)
        story.append(Image(ruta, width=ancho_pagina_util, height=ancho_pagina_util * 2.6/9.5))

    story.append(PageBreak())

    # ---- Promedio por día de la semana ----
    story.append(Paragraph("Promedio por día de la semana", H2_STYLE))
    filas_dia = [["Día", "Días obs.", "Contestadas prom.", "Mín–Máx", "Abandonadas prom.", "TMO"]]
    for d in resumen_dia:
        tmo = d["tmo_seg_promedio"]
        filas_dia.append([
            d["dia_semana"], str(d["dias_observados"]), f"{d['contestadas_promedio']:.0f}",
            f"{d['contestadas_min']}–{d['contestadas_max']}", f"{d['abandonadas_promedio']:.0f}",
            f"{int(tmo//60)}:{int(tmo%60):02d}",
        ])
    t2 = Table(filas_dia, colWidths=[3*cm, 2.5*cm, 3.5*cm, 3*cm, 3.5*cm, 2.5*cm], repeatRows=1)
    t2.setStyle(TableStyle(ESTILO_TABLA_HEADER_NEGRO + [("FONTSIZE", (0, 0), (-1, -1), 9)]))
    story.append(t2)
    story.append(Spacer(1, 16))

    # ---- Desglose completo por franja horaria y día ----
    if not desglose.empty:
        story.append(Paragraph("Desglose por franja horaria y día (llamadas contestadas / TMO)", H2_STYLE))
        orden_dias = DIAS_SEMANA
        horas_presentes = sorted(desglose["hora_del_dia"].unique())
        indice = {(r["dia_semana"], r["hora_del_dia"]): r for _, r in desglose.iterrows()}

        filas_matriz = [["Franja"] + orden_dias]
        for h in horas_presentes:
            fila = [f"{int(h):02d}:00"]
            for dia in orden_dias:
                r = indice.get((dia, h))
                if r is not None:
                    tmo = r["tmo_seg_prom"]
                    fila.append(f"{r['llamadas_contestadas_prom_dia']:.0f} ({int(tmo//60)}:{int(tmo%60):02d})")
                else:
                    fila.append("—")
            filas_matriz.append(fila)

        t3 = Table(filas_matriz, colWidths=[2.2*cm] + [3.1*cm]*7, repeatRows=1)
        t3.setStyle(TableStyle(ESTILO_TABLA_HEADER_NEGRO + [("FONTSIZE", (0, 0), (-1, -1), 7.5)]))
        story.append(t3)

    story.extend(_pie_pagina())
    doc.build(story, onFirstPage=_numero_pagina, onLaterPages=_numero_pagina)

    for ruta in rutas_temp:
        if os.path.exists(ruta):
            os.remove(ruta)

    return salida
    return salida


if __name__ == "__main__":
    import sys
    from datetime import timedelta
    if len(sys.argv) > 1:
        lunes = date.fromisoformat(sys.argv[1])
    else:
        hoy = date.today()
        lunes = hoy + timedelta(days=(7 - hoy.weekday()) % 7 or 7)
    sl = float(sys.argv[2]) if len(sys.argv) > 2 else 0.95
    ruta = generar_pdf_brecha_personal(lunes, target_service_level=sl)
    print(f"PDF generado: {ruta}")
