"""
db.py
Capa de datos del módulo de Personal / Disponibilidad.
Usa SQLite (archivo local, cero configuración). El SQL es estándar,
así que migrar a PostgreSQL más adelante (para la versión en línea)
es un cambio mínimo (mismo esquema, mismo tipo de queries).
"""

import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Optional

DB_PATH = "callcenter.db"

DIAS_SEMANA = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

# Valores por defecto pedidos por el negocio (configurables por empleado si aplica)
DEFAULT_HORAS_MIN_SEMANA = 22
DEFAULT_HORAS_MAX_SEMANA = 36
DEFAULT_HORAS_MIN_DIA = 4
DEFAULT_HORAS_MAX_DIA = 8

TIPOS_DISPONIBILIDAD = ("completa", "rango", "no_disponible", "sin_informacion")
TIPOS_PERMISO = ("vacaciones", "capacitacion", "incapacidad", "permiso_remunerado", "permiso_no_remunerado", "otro")


@contextmanager
def get_conn(db_path: str = DB_PATH):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(db_path: str = DB_PATH):
    with get_conn(db_path) as conn:
        conn.executescript(f"""
        CREATE TABLE IF NOT EXISTS empleados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            cedula TEXT,
            activo INTEGER NOT NULL DEFAULT 1,
            horas_min_dia REAL NOT NULL DEFAULT {DEFAULT_HORAS_MIN_DIA},
            horas_max_dia REAL NOT NULL DEFAULT {DEFAULT_HORAS_MAX_DIA},
            horas_min_semana REAL NOT NULL DEFAULT {DEFAULT_HORAS_MIN_SEMANA},
            horas_max_semana REAL NOT NULL DEFAULT {DEFAULT_HORAS_MAX_SEMANA}
        );

        CREATE TABLE IF NOT EXISTS disponibilidad (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empleado_id INTEGER NOT NULL REFERENCES empleados(id) ON DELETE CASCADE,
            dia_semana TEXT NOT NULL,
            tipo TEXT NOT NULL,          -- completa | rango | no_disponible | sin_informacion
            hora_inicio TEXT,            -- 'HH:MM' si tipo = rango
            hora_fin TEXT,               -- 'HH:MM' si tipo = rango
            UNIQUE(empleado_id, dia_semana)
        );

        CREATE TABLE IF NOT EXISTS permisos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empleado_id INTEGER NOT NULL REFERENCES empleados(id) ON DELETE CASCADE,
            tipo TEXT NOT NULL,          -- vacaciones | capacitacion | incapacidad | ...
            fecha_inicio TEXT NOT NULL,  -- 'YYYY-MM-DD'
            fecha_fin TEXT NOT NULL,     -- 'YYYY-MM-DD'
            comentario TEXT
        );

        CREATE TABLE IF NOT EXISTS llamadas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT,
            campana TEXT NOT NULL,
            fecha TEXT NOT NULL,          -- 'YYYY-MM-DD'
            hora TEXT NOT NULL,           -- 'HH:MM:SS'
            espera_seg REAL,
            duracion_seg REAL,
            agente TEXT,
            resultado TEXT NOT NULL,      -- 'Contestada' | 'Abandonada'
            hash_unico TEXT NOT NULL UNIQUE   -- evita duplicar la misma llamada si se recarga el archivo
        );
        CREATE INDEX IF NOT EXISTS idx_llamadas_fecha ON llamadas(fecha);

        CREATE TABLE IF NOT EXISTS tarifas (
            id INTEGER PRIMARY KEY CHECK (id = 1),   -- fila única, se actualiza siempre
            valor_hora_normal REAL NOT NULL,
            valor_recargo_dominical REAL NOT NULL,   -- tarifa hora trabajada en domingo
            valor_recargo_nocturno REAL NOT NULL,    -- adicional por hora desde las 19:00
            valor_subsidio_transporte_hora REAL NOT NULL
        );
        """)

        conn.execute("""
            INSERT OR IGNORE INTO tarifas (id, valor_hora_normal, valor_recargo_dominical,
                                            valor_recargo_nocturno, valor_subsidio_transporte_hora)
            VALUES (1, 9285, 14326, 2786, 8303)
        """)

        # Migración: si la BD ya existía de antes (sin la columna cedula), se agrega ahora.
        columnas = [r["name"] for r in conn.execute("PRAGMA table_info(empleados)").fetchall()]
        if "cedula" not in columnas:
            conn.execute("ALTER TABLE empleados ADD COLUMN cedula TEXT")


# ---------- CRUD: Empleados ----------

def crear_empleado(nombre, cedula=None, horas_min_dia=DEFAULT_HORAS_MIN_DIA, horas_max_dia=DEFAULT_HORAS_MAX_DIA,
                    horas_min_semana=DEFAULT_HORAS_MIN_SEMANA, horas_max_semana=DEFAULT_HORAS_MAX_SEMANA,
                    db_path: str = DB_PATH) -> int:
    with get_conn(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO empleados (nombre, cedula, horas_min_dia, horas_max_dia, horas_min_semana, horas_max_semana) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (nombre, cedula, horas_min_dia, horas_max_dia, horas_min_semana, horas_max_semana),
        )
        return cur.lastrowid


def listar_empleados(solo_activos: bool = True, db_path: str = DB_PATH):
    with get_conn(db_path) as conn:
        q = "SELECT * FROM empleados"
        if solo_activos:
            q += " WHERE activo = 1"
        return [dict(r) for r in conn.execute(q).fetchall()]


def obtener_empleado(empleado_id: int, db_path: str = DB_PATH):
    with get_conn(db_path) as conn:
        r = conn.execute("SELECT * FROM empleados WHERE id = ?", (empleado_id,)).fetchone()
        return dict(r) if r else None


def actualizar_empleado(empleado_id: int, db_path: str = DB_PATH, **campos):
    if not campos:
        return
    sets = ", ".join(f"{k} = ?" for k in campos)
    with get_conn(db_path) as conn:
        conn.execute(f"UPDATE empleados SET {sets} WHERE id = ?", (*campos.values(), empleado_id))


def eliminar_empleado(empleado_id: int, db_path: str = DB_PATH, definitivo: bool = False):
    """Por defecto hace 'soft delete' (activo=0) para no perder historial de horarios pasados."""
    with get_conn(db_path) as conn:
        if definitivo:
            conn.execute("DELETE FROM empleados WHERE id = ?", (empleado_id,))
        else:
            conn.execute("UPDATE empleados SET activo = 0 WHERE id = ?", (empleado_id,))


# ---------- CRUD: Disponibilidad ----------

def set_disponibilidad(empleado_id: int, dia_semana: str, tipo: str,
                        hora_inicio: Optional[str] = None, hora_fin: Optional[str] = None,
                        db_path: str = DB_PATH):
    assert dia_semana in DIAS_SEMANA, f"Día inválido: {dia_semana}"
    assert tipo in TIPOS_DISPONIBILIDAD, f"Tipo inválido: {tipo}"
    if tipo == "rango":
        assert hora_inicio and hora_fin, "Un rango necesita hora_inicio y hora_fin"

    with get_conn(db_path) as conn:
        conn.execute("""
            INSERT INTO disponibilidad (empleado_id, dia_semana, tipo, hora_inicio, hora_fin)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(empleado_id, dia_semana) DO UPDATE SET
                tipo = excluded.tipo, hora_inicio = excluded.hora_inicio, hora_fin = excluded.hora_fin
        """, (empleado_id, dia_semana, tipo, hora_inicio, hora_fin))


def obtener_disponibilidad(empleado_id: int, db_path: str = DB_PATH):
    with get_conn(db_path) as conn:
        rows = conn.execute(
            "SELECT * FROM disponibilidad WHERE empleado_id = ?", (empleado_id,)
        ).fetchall()
        return {r["dia_semana"]: dict(r) for r in rows}


# ---------- CRUD: Permisos (vacaciones, capacitación, etc.) ----------

def crear_permiso(empleado_id: int, tipo: str, fecha_inicio: str, fecha_fin: str,
                   comentario: str = "", db_path: str = DB_PATH, forzar: bool = False) -> int:
    assert tipo in TIPOS_PERMISO, f"Tipo de permiso inválido: {tipo}"
    if fecha_fin < fecha_inicio:
        raise ValueError("fecha_fin no puede ser anterior a fecha_inicio")

    if not forzar:
        solapados = permisos_solapados(empleado_id, fecha_inicio, fecha_fin, db_path=db_path)
        if solapados:
            raise ValueError(
                f"Ya existe un permiso que se solapa en esas fechas: {solapados}. "
                f"Usa forzar=True si de verdad quieres crearlo igual (ej. permisos parciales del mismo día)."
            )

    with get_conn(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO permisos (empleado_id, tipo, fecha_inicio, fecha_fin, comentario) VALUES (?, ?, ?, ?, ?)",
            (empleado_id, tipo, fecha_inicio, fecha_fin, comentario),
        )
        return cur.lastrowid


def permisos_solapados(empleado_id: int, fecha_inicio: str, fecha_fin: str, db_path: str = DB_PATH):
    """Devuelve los permisos existentes de ese empleado cuyo rango de fechas se cruza con el nuevo."""
    with get_conn(db_path) as conn:
        rows = conn.execute(
            """SELECT * FROM permisos
               WHERE empleado_id = ?
                 AND fecha_inicio <= ? AND fecha_fin >= ?""",
            (empleado_id, fecha_fin, fecha_inicio),
        ).fetchall()
        return [dict(r) for r in rows]


def listar_permisos(empleado_id: Optional[int] = None, db_path: str = DB_PATH):
    with get_conn(db_path) as conn:
        if empleado_id:
            rows = conn.execute("SELECT * FROM permisos WHERE empleado_id = ?", (empleado_id,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM permisos").fetchall()
        return [dict(r) for r in rows]


def eliminar_permiso(permiso_id: int, db_path: str = DB_PATH):
    with get_conn(db_path) as conn:
        conn.execute("DELETE FROM permisos WHERE id = ?", (permiso_id,))


def empleados_de_permiso_en_fecha(fecha: str, db_path: str = DB_PATH):
    """fecha en formato 'YYYY-MM-DD'. Devuelve empleados con permiso activo ese día (para excluirlos del horario)."""
    with get_conn(db_path) as conn:
        rows = conn.execute(
            """SELECT p.*, e.nombre FROM permisos p
               JOIN empleados e ON e.id = p.empleado_id
               WHERE p.fecha_inicio <= ? AND p.fecha_fin >= ?""",
            (fecha, fecha),
        ).fetchall()
        return [dict(r) for r in rows]


# ---------- Llamadas (histórico, carga incremental) ----------

def insertar_llamadas_bulk(filas: list[dict], db_path: str = DB_PATH) -> dict:
    """
    Inserta llamadas en bloque. Cada fila debe traer 'hash_unico' ya calculado.
    Usa INSERT OR IGNORE: si la llamada ya existía (mismo hash), la salta sin error.
    Devuelve cuántas se insertaron realmente vs cuántas ya existían.
    """
    with get_conn(db_path) as conn:
        antes = conn.execute("SELECT COUNT(*) c FROM llamadas").fetchone()["c"]
        conn.executemany("""
            INSERT OR IGNORE INTO llamadas
                (numero, campana, fecha, hora, espera_seg, duracion_seg, agente, resultado, hash_unico)
            VALUES (:numero, :campana, :fecha, :hora, :espera_seg, :duracion_seg, :agente, :resultado, :hash_unico)
        """, filas)
        despues = conn.execute("SELECT COUNT(*) c FROM llamadas").fetchone()["c"]
    return {"insertadas_nuevas": despues - antes, "ya_existian": len(filas) - (despues - antes)}


def rango_fechas_llamadas(db_path: str = DB_PATH):
    with get_conn(db_path) as conn:
        r = conn.execute("SELECT MIN(fecha) mn, MAX(fecha) mx, COUNT(*) c FROM llamadas").fetchone()
        return dict(r)


def obtener_llamadas_df(db_path: str = DB_PATH):
    """Devuelve TODAS las llamadas históricas como lista de dicts (para pasar a pandas)."""
    with get_conn(db_path) as conn:
        rows = conn.execute("SELECT * FROM llamadas").fetchall()
        return [dict(r) for r in rows]


# ---------- Tarifas (configurable desde la plataforma) ----------

def obtener_tarifas(db_path: str = DB_PATH) -> dict:
    with get_conn(db_path) as conn:
        r = conn.execute("SELECT * FROM tarifas WHERE id = 1").fetchone()
        return dict(r)


def actualizar_tarifas(db_path: str = DB_PATH, **campos):
    if not campos:
        return
    sets = ", ".join(f"{k} = ?" for k in campos)
    with get_conn(db_path) as conn:
        conn.execute(f"UPDATE tarifas SET {sets} WHERE id = 1", (*campos.values(),))
    return obtener_tarifas(db_path=db_path)
