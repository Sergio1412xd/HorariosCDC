"""
generador_horarios.py
Genera el cuadrante semanal cruzando:
  - Demanda por hora (Erlang C, usando el histórico real, desglosado por día de la
    semana cuando hay datos suficientes -- un sábado no se dimensiona igual que un martes)
  - Disponibilidad de cada asesor (por día de la semana)
  - Permisos (vacaciones, capacitación, etc.) para las fechas exactas de esa semana
  - Reglas de horas mín/máx diarias y semanales de cada asesor

Turnos de duración VARIABLE (entre horas_min_dia y horas_max_dia), ajustados para cubrir
la demanda lo mejor posible.

NOTA HONESTA SOBRE EL ALGORITMO: esto es un algoritmo "voraz" (greedy) con reparación,
no un optimizador matemático exacto (no garantiza la solución matemáticamente óptima como
lo haría un solver de programación lineal). Se eligió así a propósito porque es transparente
y fácil de entender/ajustar línea por línea. En la práctica da resultados muy buenos porque
sigue una regla simple y efectiva: en cada paso, cubre primero la hora con MÁS gente faltando,
priorizando al asesor cuyo turno cubra más horas de déficit y que más necesite acercarse a su
mínimo semanal. Si en el futuro se necesita exprimir el último 2-3% de eficiencia, se puede
reemplazar por un solver (OR-Tools) sin tocar el resto del sistema.
"""

import math
from datetime import date, timedelta

from db import listar_empleados, obtener_disponibilidad, empleados_de_permiso_en_fecha, DIAS_SEMANA
from agregados_llamadas import resumen_por_dia_semana_y_hora_ponderado, resumen_por_hora
from erlang import required_agents

HORARIO_OPERATIVO_INICIO = 11   # 11:00
HORARIO_OPERATIVO_FIN = 23      # 23:00 (fin exclusivo -> última hora programable es 22:00-23:00)
DOMINGO_MAX_HORAS = 7           # tope de horas por turno los domingos (recargo dominical más costoso)


def _ancho_bloque_deficit(deficits: dict, hi: int, hf: int, hora_pico: int) -> int:
    """
    Cuenta cuántas horas CONSECUTIVAS alrededor de hora_pico (dentro de [hi, hf)) todavía
    tienen déficit. Se usa para no asignar turnos más largos de lo que el pico realmente
    necesita -- un turno de 8h cuando el pico dura solo 3h desperdicia 5h que podrían usarse
    en otro día/hora con déficit real.
    """
    izq = hora_pico
    while izq - 1 >= hi and deficits.get(izq - 1, 0) > 0:
        izq -= 1
    der = hora_pico
    while der + 1 < hf and deficits.get(der + 1, 0) > 0:
        der += 1
    return der - izq + 1


def _demanda_por_dia(db_path, target_service_level, shrinkage, factor_decaimiento=0.7):
    """Devuelve {dia_semana: {hora: agentes_requeridos}}, ponderando semanas recientes,
    y completando con el promedio general si algún día de semana no tiene datos aún."""
    datos = _datos_demanda_por_dia(db_path, target_service_level, shrinkage, factor_decaimiento)
    return {dia: {h: v["agentes_requeridos"] for h, v in horas.items()} for dia, horas in datos.items()}


def _datos_demanda_por_dia(db_path, target_service_level, shrinkage, factor_decaimiento=0.7):
    """Igual que _demanda_por_dia pero conserva también 'calls' y 'aht_seconds' de cada hora,
    necesarios luego para estimar el nivel de servicio REAL que da un horario ya generado."""
    tabla_dia = resumen_por_dia_semana_y_hora_ponderado(db_path=db_path, factor_decaimiento=factor_decaimiento)
    datos = {}

    if not tabla_dia.empty:
        for dia in tabla_dia["dia_semana"].unique():
            sub = tabla_dia[tabla_dia["dia_semana"] == dia]
            datos[dia] = {}
            for _, fila in sub.iterrows():
                calls = round(fila["llamadas_contestadas_prom_dia"])
                aht = fila["tmo_seg_prom"] if fila["tmo_seg_prom"] > 0 else 150
                r = required_agents(calls=calls, aht_seconds=aht,
                                     target_service_level=target_service_level, shrinkage=shrinkage)
                datos[dia][int(fila["hora_del_dia"])] = {
                    "agentes_requeridos": r.agents_final, "calls": calls, "aht_seconds": aht,
                }

    tabla_general = resumen_por_hora(db_path=db_path)
    datos_general = {}
    for _, fila in tabla_general.iterrows():
        calls = round(fila["llamadas_contestadas_prom_dia"])
        aht = fila["tmo_seg_prom"] if fila["tmo_seg_prom"] > 0 else 150
        r = required_agents(calls=calls, aht_seconds=aht,
                             target_service_level=target_service_level, shrinkage=shrinkage)
        datos_general[int(fila["hora_del_dia"])] = {
            "agentes_requeridos": r.agents_final, "calls": calls, "aht_seconds": aht,
        }

    for dia in DIAS_SEMANA:
        if dia not in datos or not datos[dia]:
            datos[dia] = datos_general

    return datos


def _ventana_disponibilidad(disp_dia, dia_semana):
    """(hora_inicio, hora_fin) enteros, o None si no disponible ese día."""
    if not disp_dia:
        return None
    tipo = disp_dia["tipo"]
    if tipo == "completa":
        return (HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN)
    if tipo == "rango":
        hi = int(disp_dia["hora_inicio"].split(":")[0])
        hf = int(disp_dia["hora_fin"].split(":")[0])
        return (max(hi, HORARIO_OPERATIVO_INICIO), min(hf, HORARIO_OPERATIVO_FIN))
    return None  # no_disponible / sin_informacion


def generar_horario_semana(fecha_lunes: date, db_path: str = "callcenter.db",
                            target_service_level: float = 0.95, shrinkage: float = 0.30,
                            fraccion_equidad: float = 0.40):
    """
    fecha_lunes: el lunes (date) de la semana a programar.
    Devuelve dict con 'horario', 'cobertura', 'alertas', 'horas_semana'.
    """
    empleados = listar_empleados(db_path=db_path)
    datos_demanda = _datos_demanda_por_dia(db_path, target_service_level, shrinkage)
    demanda = {dia: {h: v["agentes_requeridos"] for h, v in horas.items()} for dia, horas in datos_demanda.items()}
    fechas_semana = {DIAS_SEMANA[i]: fecha_lunes + timedelta(days=i) for i in range(7)}

    horario = {e["nombre"]: {} for e in empleados}
    horas_semana = {e["nombre"]: 0.0 for e in empleados}
    alertas = []
    cobertura = {}
    candidatos_por_dia = {}
    asignados_por_dia = {dia: set() for dia in DIAS_SEMANA}

    disponibilidad_cache = {e["id"]: obtener_disponibilidad(e["id"], db_path=db_path) for e in empleados}

    # ---- Preparar candidatos y cobertura inicial de cada día (permisos, disponibilidad) ----
    for dia in DIAS_SEMANA:
        fecha_str = fechas_semana[dia].strftime("%Y-%m-%d")
        demanda_dia = demanda.get(dia, {})
        permisos_hoy = empleados_de_permiso_en_fecha(fecha_str, db_path=db_path)
        permisos_por_nombre = {p["nombre"]: p["tipo"] for p in permisos_hoy}

        cobertura[dia] = {
            h: {"requeridos": demanda_dia.get(h, 0), "programados": 0,
                "calls": datos_demanda.get(dia, {}).get(h, {}).get("calls", 0),
                "aht_seconds": datos_demanda.get(dia, {}).get(h, {}).get("aht_seconds", 150)}
            for h in range(HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN)
        }

        candidatos = []
        for e in empleados:
            nombre = e["nombre"]
            if nombre in permisos_por_nombre:
                horario[nombre][dia] = {"motivo": f"permiso:{permisos_por_nombre[nombre]}"}
                continue
            disp = disponibilidad_cache[e["id"]].get(dia)
            ventana = _ventana_disponibilidad(disp, dia)
            if ventana is None:
                motivo = "sin_informacion" if (disp and disp["tipo"] == "sin_informacion") else "no_disponible"
                horario[nombre][dia] = {"motivo": motivo}
                continue
            candidatos.append((e, ventana))
        candidatos_por_dia[dia] = candidatos

    def _procesar_dia(dia, tope_duracion, fraccion_objetivo=1.0):
        """
        Corre el llenado voraz de déficit para un día, respetando lo ya asignado en fases
        anteriores. 'tope_duracion(e)' define la duración MÁXIMA de turno permitida para
        cada empleado en esta pasada. 'fraccion_objetivo' define hasta qué % de lo requerido
        se intenta cubrir en esta pasada (en la fase 1 se usa una fracción baja para dejar
        candidatos disponibles para la fase 2, en vez de agotar a todo el mundo de una vez).
        """
        candidatos = candidatos_por_dia[dia]
        asignados_hoy = asignados_por_dia[dia]
        max_iter = len(candidatos) + 5

        for _ in range(max_iter):
            deficits = {}
            for h, c in cobertura[dia].items():
                techo = max(1, round(c["requeridos"] * fraccion_objetivo)) if c["requeridos"] > 0 else 0
                d = techo - c["programados"]
                if d > 0:
                    deficits[h] = d
            if not deficits:
                break

            hora_pico = max(deficits, key=deficits.get)

            mejor, mejor_score = None, -1
            for e, (hi, hf) in candidatos:
                nombre = e["nombre"]
                if nombre in asignados_hoy or not (hi <= hora_pico < hf):
                    continue
                restante_semana = e["horas_max_semana"] - horas_semana[nombre]
                if restante_semana < e["horas_min_dia"]:
                    continue
                max_dur = min(tope_duracion(e), hf - hi, restante_semana)
                if dia == "Domingo":
                    max_dur = min(max_dur, DOMINGO_MAX_HORAS)
                if max_dur < e["horas_min_dia"]:
                    continue

                utilidad = sum(1 for h in range(hi, hf) if deficits.get(h, 0) > 0)
                urgencia_minimo = max(0, e["horas_min_semana"] - horas_semana[nombre])
                score = utilidad * 10 + urgencia_minimo
                if score > mejor_score:
                    mejor_score, mejor = score, (e, hi, hf, max_dur)

            if mejor is None:
                break

            e, hi, hf, max_dur = mejor
            nombre = e["nombre"]

            # La duración real del turno se ajusta al ancho del bloque de déficit que hay
            # alrededor de la hora pico -- no siempre al máximo permitido. Esto evita que un
            # pico corto (ej. 3h) consuma un turno completo de 8h, desperdiciando horas que
            # podrían cubrir déficit en OTRO día u otra franja.
            ancho_bloque = _ancho_bloque_deficit(deficits, hi, hf, hora_pico)
            duracion = max(int(e["horas_min_dia"]), min(int(math.floor(max_dur)), ancho_bloque))

            inicio_min = max(hi, hora_pico - duracion + 1)
            inicio_max = min(hora_pico, hf - duracion)
            mejor_inicio, mejor_peso = inicio_min, -1
            for inicio_c in range(inicio_min, inicio_max + 1):
                peso = sum(deficits.get(h, 0) for h in range(inicio_c, inicio_c + duracion))
                if peso > mejor_peso:
                    mejor_peso, mejor_inicio = peso, inicio_c

            inicio, fin = mejor_inicio, mejor_inicio + duracion
            horario[nombre][dia] = {"inicio": inicio, "fin": fin}
            asignados_hoy.add(nombre)
            horas_semana[nombre] += duracion
            for h in range(inicio, fin):
                cobertura[dia][h]["programados"] += 1

    # ---- PASE 1 (equidad): reservar una base de cobertura en TODOS los días -- empezando
    # por los más tranquilos -- ANTES de que los días de mayor demanda agoten el presupuesto
    # semanal de todos. Sin esto, los días tranquilos se procesan de últimos y se quedan sin
    # nadie disponible (todos ya tocaron su tope semanal en los días fuertes). Los turnos ya
    # se ajustan al ancho real del pico (ver _ancho_bloque_deficit), así que esta pasada no
    # desperdicia horas de más como sí pasaba con turnos cortos forzados.
    orden_ascendente = sorted(DIAS_SEMANA, key=lambda d: sum(demanda.get(d, {}).values()))
    for dia in orden_ascendente:
        _procesar_dia(dia, tope_duracion=lambda e: e["horas_max_dia"], fraccion_objetivo=fraccion_equidad)

    # ---- PASE 2 (prioridad): con el presupuesto restante, terminar de cubrir la demanda
    # empezando por los días de MAYOR intensidad (típicamente viernes-domingo). ----
    orden_descendente = sorted(DIAS_SEMANA, key=lambda d: -sum(demanda.get(d, {}).values()))
    for dia in orden_descendente:
        _procesar_dia(dia, tope_duracion=lambda e: e["horas_max_dia"], fraccion_objetivo=1.0)

    # ---- PASE DE REPARACIÓN: cualquier hora que haya quedado en CERO programados (mientras
    # se requería gente), se rellena con quien todavía tenga disponibilidad y presupuesto
    # semanal, aunque sea con un turno corto. Esto evita que un día quede completamente
    # desatendido en alguna franja, sin desperdiciar capacidad en el resto de horas. ----
    for dia in DIAS_SEMANA:
        for h in range(HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN):
            if cobertura[dia][h]["requeridos"] > 0 and cobertura[dia][h]["programados"] == 0:
                candidatos = candidatos_por_dia[dia]
                asignados_hoy = asignados_por_dia[dia]

                mejor = None
                for e, (hi, hf) in candidatos:
                    nombre = e["nombre"]
                    if nombre in asignados_hoy or not (hi <= h < hf):
                        continue
                    restante_semana = e["horas_max_semana"] - horas_semana[nombre]
                    if restante_semana < e["horas_min_dia"]:
                        continue
                    tope_dia = min(e["horas_max_dia"], DOMINGO_MAX_HORAS) if dia == "Domingo" else e["horas_max_dia"]
                    mejor = (e, hi, hf, min(tope_dia, hf - hi, restante_semana), False)
                    break

                if mejor is None:
                    # Último recurso: nadie cumple el mínimo de turno completo -- mejor una
                    # persona por menos tiempo del mínimo habitual que dejar la hora en cero.
                    # Se marca explícitamente como turno de excepción para que quede visible.
                    for e, (hi, hf) in candidatos:
                        nombre = e["nombre"]
                        if nombre in asignados_hoy or not (hi <= h < hf):
                            continue
                        restante_semana = e["horas_max_semana"] - horas_semana[nombre]
                        if restante_semana <= 0:
                            continue
                        tope_dia = DOMINGO_MAX_HORAS if dia == "Domingo" else (hf - h)
                        mejor = (e, hi, hf, min(hf - h, restante_semana, tope_dia), True)
                        break

                if mejor:
                    e, hi, hf, max_dur, es_excepcion = mejor
                    nombre = e["nombre"]
                    if es_excepcion:
                        duracion = max(1, int(math.floor(max_dur)))
                        inicio, fin = h, min(hf, h + duracion)
                    else:
                        duracion = max(int(e["horas_min_dia"]), min(int(math.floor(max_dur)), hf - h))
                        inicio = max(hi, min(h, hf - duracion))
                        fin = min(hf, inicio + duracion)
                    horario[nombre][dia] = {"inicio": inicio, "fin": fin, "excepcion": es_excepcion}
                    asignados_hoy.add(nombre)
                    horas_semana[nombre] += (fin - inicio)
                    for hh in range(inicio, fin):
                        cobertura[dia][hh]["programados"] += 1

    # ---- Cerrar: marcar "libre" a quien tenía disponibilidad pero no se necesitó, y alertas ----
    for dia in DIAS_SEMANA:
        for e, _ in candidatos_por_dia[dia]:
            if e["nombre"] not in asignados_por_dia[dia] and dia not in horario[e["nombre"]]:
                motivo = "tope_semanal_alcanzado" if horas_semana[e["nombre"]] >= e["horas_max_semana"] else "libre_no_requerido"
                horario[e["nombre"]][dia] = {"motivo": motivo}

        for h in range(HORARIO_OPERATIVO_INICIO, HORARIO_OPERATIVO_FIN):
            req, prog = cobertura[dia][h]["requeridos"], cobertura[dia][h]["programados"]
            if prog < req:
                alertas.append(f"{dia} {h}:00 -- faltan {req - prog} agente(s) (requeridos {req}, programados {prog})")

    for e in empleados:
        nombre = e["nombre"]
        if horas_semana[nombre] < e["horas_min_semana"]:
            alertas.append(
                f"{nombre}: quedó en {horas_semana[nombre]:.0f}h esta semana, por debajo de su mínimo "
                f"contractual de {e['horas_min_semana']:.0f}h (no hubo suficiente demanda/disponibilidad "
                f"para asignarle más)"
            )

    return {"horario": horario, "cobertura": cobertura, "alertas": alertas, "horas_semana": horas_semana}


def estimar_nivel_servicio_real(resultado: dict, target_answer_seconds: float = 20) -> dict:
    """
    Toma el resultado de generar_horario_semana() y calcula, con los agentes REALMENTE
    programados (no los ideales), qué % de llamadas se estima contestar -- usando la misma
    fórmula Erlang C pero "hacia adelante" (dado N agentes, ¿qué service level da?).
    Se pondera por volumen de llamadas para dar un % global realista de toda la semana.
    """
    from erlang import service_level

    detalle_por_dia = {}
    suma_ponderada, suma_calls = 0.0, 0.0

    for dia, horas in resultado["cobertura"].items():
        suma_ponderada_dia, suma_calls_dia = 0.0, 0.0
        detalle_horas = []
        for h, c in horas.items():
            calls = c.get("calls", 0)
            if calls <= 0:
                continue
            aht = c.get("aht_seconds", 150)
            A = (calls * aht) / 3600
            sl = service_level(A, c["programados"], aht, target_answer_seconds) if c["programados"] > 0 else 0.0
            detalle_horas.append({"hora": h, "calls": calls, "programados": c["programados"], "sl_estimado_pct": round(sl * 100, 1)})
            suma_ponderada_dia += sl * calls
            suma_calls_dia += calls

        sl_dia = (suma_ponderada_dia / suma_calls_dia * 100) if suma_calls_dia > 0 else None
        detalle_por_dia[dia] = {"sl_estimado_pct": round(sl_dia, 1) if sl_dia is not None else None, "horas": detalle_horas}
        suma_ponderada += suma_ponderada_dia
        suma_calls += suma_calls_dia

    sl_semana = round(suma_ponderada / suma_calls * 100, 1) if suma_calls > 0 else None
    return {"sl_estimado_semana_pct": sl_semana, "por_dia": detalle_por_dia}


def imprimir_horario(resultado):
    print(f"{'Asesor':<22}" + "".join(f"{d[:3]:>12}" for d in DIAS_SEMANA))
    print("-" * (22 + 12 * 7))
    for nombre, dias in resultado["horario"].items():
        fila = f"{nombre:<22}"
        for dia in DIAS_SEMANA:
            info = dias.get(dia, {"motivo": "?"})
            if "inicio" in info:
                txt = f"{info['inicio']:02d}-{info['fin']:02d}h"
            else:
                mapa = {"no_disponible": "No disp.", "sin_informacion": "Sin info", "libre_no_requerido": "Libre",
                        "tope_semanal_alcanzado": "Tope sem."}
                txt = mapa.get(info["motivo"], info["motivo"])[:11]
            fila += f"{txt:>12}"
        print(fila, f"   ({resultado['horas_semana'][nombre]:.0f}h)")

    print("\n=== Cobertura vs demanda (requeridos / programados por hora) ===")
    for dia in DIAS_SEMANA:
        linea = f"{dia:<12}"
        for h, c in resultado["cobertura"][dia].items():
            marca = "!" if c["programados"] < c["requeridos"] else " "
            linea += f"{h}:{c['requeridos']}/{c['programados']}{marca} "
        print(linea)

    if resultado["alertas"]:
        print(f"\n=== Alertas ({len(resultado['alertas'])}) ===")
        for a in resultado["alertas"]:
            print(" -", a)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        lunes = date.fromisoformat(sys.argv[1])
    else:
        hoy = date.today()
        lunes = hoy + timedelta(days=(7 - hoy.weekday()) % 7 or 7)  # próximo lunes

    print(f"Generando horario para la semana del {lunes.isoformat()}\n")
    resultado = generar_horario_semana(lunes)
    imprimir_horario(resultado)
